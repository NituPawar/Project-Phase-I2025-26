import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { User, LogOut, FileText, Plus, Clock, CheckCircle, XCircle, Download, Upload, Home, Mail, Eye } from 'lucide-react';
import { generateCertificate } from './CertificateGenerator';
import { getEmailPreview } from '../utils/emailService';

interface CitizenDashboardProps {
  user: any;
  onLogout: () => void;
  onGoHome: () => void;
}

export function CitizenDashboard({ user, onLogout, onGoHome }: CitizenDashboardProps) {
  const [applications, setApplications] = useState<any[]>([]);
  const [newAppDialogOpen, setNewAppDialogOpen] = useState(false);
  const [emailDialogOpen, setEmailDialogOpen] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState<any>(null);
  const [formData, setFormData] = useState({
    applicantName: user.name,
    fatherName: '',
    dob: '',
    caste: '',
    address: user.address || '',
    phone: user.phone || '',
    aadhaarNumber: '',
    district: user.district || '',
    documents: [] as any[]
  });

  useEffect(() => {
    loadApplications();
  }, [user]);

  const loadApplications = () => {
    const apps = JSON.parse(localStorage.getItem('applications') || '[]');
    const myApps = apps.filter((app: any) => app.citizenId === user.id);
    setApplications(myApps);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    // Convert files to base64 and store with metadata
    const filePromises = files.map((file) => {
      return new Promise<any>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => {
          resolve({
            name: file.name,
            size: file.size,
            type: file.type,
            data: reader.result as string // base64 encoded file data
          });
        };
        reader.readAsDataURL(file);
      });
    });
    
    const fileData = await Promise.all(filePromises);
    setFormData({ ...formData, documents: [...formData.documents, ...fileData] });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newApp = {
      id: Date.now().toString(),
      citizenId: user.id,
      ...formData,
      status: 'pending',
      createdAt: new Date().toISOString(),
      assignedTo: null
    };

    const apps = JSON.parse(localStorage.getItem('applications') || '[]');
    apps.push(newApp);
    localStorage.setItem('applications', JSON.stringify(apps));

    setNewAppDialogOpen(false);
    setFormData({
      applicantName: user.name,
      fatherName: '',
      dob: '',
      caste: '',
      address: user.address || '',
      phone: user.phone || '',
      aadhaarNumber: '',
      district: user.district || '',
      documents: []
    });
    loadApplications();
  };

  const downloadCertificate = (app: any) => {
    generateCertificate(app);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary"><Clock className="mr-1 h-3 w-3" />Pending</Badge>;
      case 'under_review':
        return <Badge className="bg-blue-500">Under Review</Badge>;
      case 'approved':
        return <Badge className="bg-green-500"><CheckCircle className="mr-1 h-3 w-3" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><XCircle className="mr-1 h-3 w-3" />Rejected</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const stats = {
    total: applications.length,
    pending: applications.filter(a => a.status === 'pending' || a.status === 'under_review').length,
    approved: applications.filter(a => a.status === 'approved').length,
    rejected: applications.filter(a => a.status === 'rejected').length
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header with Maharashtra Theme */}
      <div className="bg-gradient-to-r from-orange-500 via-white to-green-600 h-1"></div>
      <div className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center">
                <User className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-orange-700">Citizen Portal</h1>
                <p className="text-sm text-gray-600">महाराष्ट्र शासन - Online Caste Certificate</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm">{user.name}</p>
                <p className="text-xs text-gray-500">Citizen</p>
              </div>
              <Button variant="outline" onClick={onGoHome}>
                <Home className="mr-2 h-4 w-4" />
                Home
              </Button>
              <Button variant="outline" onClick={onLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-t-4 border-t-orange-500">
            <CardHeader className="pb-3">
              <CardDescription>Total Applications</CardDescription>
              <CardTitle className="text-orange-600">{stats.total}</CardTitle>
            </CardHeader>
            <CardContent>
              <FileText className="h-8 w-8 text-orange-600 opacity-50" />
            </CardContent>
          </Card>
          <Card className="border-t-4 border-t-blue-500">
            <CardHeader className="pb-3">
              <CardDescription>Pending/Under Review</CardDescription>
              <CardTitle className="text-blue-600">{stats.pending}</CardTitle>
            </CardHeader>
            <CardContent>
              <Clock className="h-8 w-8 text-blue-600 opacity-50" />
            </CardContent>
          </Card>
          <Card className="border-t-4 border-t-green-500">
            <CardHeader className="pb-3">
              <CardDescription>Approved</CardDescription>
              <CardTitle className="text-green-600">{stats.approved}</CardTitle>
            </CardHeader>
            <CardContent>
              <CheckCircle className="h-8 w-8 text-green-600 opacity-50" />
            </CardContent>
          </Card>
          <Card className="border-t-4 border-t-red-500">
            <CardHeader className="pb-3">
              <CardDescription>Rejected</CardDescription>
              <CardTitle className="text-red-600">{stats.rejected}</CardTitle>
            </CardHeader>
            <CardContent>
              <XCircle className="h-8 w-8 text-red-600 opacity-50" />
            </CardContent>
          </Card>
        </div>

        {/* New Application Button */}
        <div className="mb-6">
          <Button onClick={() => setNewAppDialogOpen(true)} size="lg" className="bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800">
            <Plus className="mr-2 h-5 w-5" />
            Apply for New Certificate
          </Button>
        </div>

        {/* Applications Table */}
        <Card>
          <CardHeader>
            <CardTitle>My Applications</CardTitle>
            <CardDescription>Track your certificate applications</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Application ID</TableHead>
                    <TableHead>Applicant Name</TableHead>
                    <TableHead>Caste</TableHead>
                    <TableHead>Applied Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {applications.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-gray-500">
                        No applications found. Click "Apply for New Certificate" to get started.
                      </TableCell>
                    </TableRow>
                  ) : (
                    applications.map((app) => (
                      <TableRow key={app.id}>
                        <TableCell className="font-mono text-xs">#{app.id.slice(0, 8)}</TableCell>
                        <TableCell>{app.applicantName}</TableCell>
                        <TableCell>{app.caste}</TableCell>
                        <TableCell>{new Date(app.createdAt).toLocaleDateString()}</TableCell>
                        <TableCell>{getStatusBadge(app.status)}</TableCell>
                        <TableCell>
                          <div className="flex flex-col gap-2">
                            {app.status === 'approved' && (
                              <Button
                                size="sm"
                                className="bg-green-600 hover:bg-green-700"
                                onClick={() => downloadCertificate(app)}
                              >
                                <Download className="h-4 w-4 mr-1" />
                                Download Certificate
                              </Button>
                            )}
                            {(app.status === 'approved' || app.status === 'rejected') && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  const emails = getEmailPreview(app.id);
                                  if (emails.length > 0) {
                                    setSelectedEmail(emails[0]);
                                    setEmailDialogOpen(true);
                                  }
                                }}
                              >
                                <Mail className="h-4 w-4 mr-1" />
                                View Email
                              </Button>
                            )}
                            {app.status === 'rejected' && app.remarks && (
                              <p className="text-xs text-red-600">Reason: {app.remarks}</p>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* New Application Dialog */}
      <Dialog open={newAppDialogOpen} onOpenChange={setNewAppDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Apply for Caste Certificate</DialogTitle>
            <DialogDescription>
              Fill in all the required details and upload necessary documents
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="applicantName">Applicant Name *</Label>
                <Input
                  id="applicantName"
                  value={formData.applicantName}
                  onChange={(e) => setFormData({ ...formData, applicantName: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fatherName">Father's Name *</Label>
                <Input
                  id="fatherName"
                  value={formData.fatherName}
                  onChange={(e) => setFormData({ ...formData, fatherName: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dob">Date of Birth *</Label>
                <Input
                  id="dob"
                  type="date"
                  value={formData.dob}
                  onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="caste">Caste Category *</Label>
                <Input
                  id="caste"
                  value={formData.caste}
                  onChange={(e) => setFormData({ ...formData, caste: e.target.value })}
                  placeholder="e.g., SC, ST, OBC, NT, etc."
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+91 XXXXXXXXXX"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="aadhaarNumber">Aadhaar Number *</Label>
                <Input
                  id="aadhaarNumber"
                  type="text"
                  value={formData.aadhaarNumber}
                  onChange={(e) => setFormData({ ...formData, aadhaarNumber: e.target.value })}
                  placeholder="XXXX XXXX XXXX"
                  maxLength={12}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="district">District *</Label>
                <Input
                  id="district"
                  value={formData.district}
                  onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                  placeholder="Your district"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Residential Address *</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="Enter complete address"
                required
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="documents">Upload Documents *</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="documents"
                  type="file"
                  multiple
                  onChange={handleFileUpload}
                  className="cursor-pointer"
                  accept=".pdf,.jpg,.jpeg,.png"
                />
                <Upload className="h-5 w-5 text-gray-400" />
              </div>
              <p className="text-xs text-gray-500">
                Required Documents: Aadhaar Card, Birth Certificate, Proof of Residence, School Leaving Certificate
              </p>
              {formData.documents.length > 0 && (
                <div className="mt-2 space-y-1">
                  {formData.documents.map((doc, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-gray-600 bg-orange-50 p-2 rounded">
                      <FileText className="h-4 w-4 text-orange-600" />
                      <span>{doc.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="flex gap-4 pt-4">
              <Button type="submit" className="flex-1 bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800">
                Submit Application
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setNewAppDialogOpen(false)}
              >
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Email Notification Dialog */}
      <Dialog open={emailDialogOpen} onOpenChange={setEmailDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Email Notification</DialogTitle>
            <DialogDescription>
              Email sent to you regarding your application
            </DialogDescription>
          </DialogHeader>
          {selectedEmail && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-xs text-gray-500">Sent To</p>
                  <p className="text-sm">{selectedEmail.to}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Sent At</p>
                  <p className="text-sm">
                    {new Date(selectedEmail.sentAt).toLocaleString('en-IN', {
                      day: '2-digit',
                      month: 'long',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
                <div className="col-span-2">
                  <p className="text-xs text-gray-500">Status</p>
                  <div className="mt-1">
                    {selectedEmail.status === 'approved' ? (
                      <Badge className="bg-green-500">
                        <CheckCircle className="mr-1 h-3 w-3" />
                        Application Approved
                      </Badge>
                    ) : (
                      <Badge variant="destructive">
                        <XCircle className="mr-1 h-3 w-3" />
                        Application Rejected
                      </Badge>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-700 mb-2">Subject:</p>
                <p className="text-sm p-3 bg-blue-50 rounded">{selectedEmail.subject}</p>
              </div>

              <div>
                <p className="text-sm text-gray-700 mb-2">Email Content:</p>
                <div className="p-4 bg-white border rounded-lg max-h-96 overflow-y-auto">
                  <pre className="text-sm whitespace-pre-wrap font-sans">{selectedEmail.content}</pre>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
