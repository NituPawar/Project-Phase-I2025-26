# Maharashtra Government - Online Caste Certificate Issuance System

## Project Overview
A complete e-governance application for online caste certificate issuance by the Maharashtra Revenue Department with real-time data monitoring, role-based access control, document management, and an attractive public-facing website.

## System Architecture
- **Frontend**: React with TypeScript, Tailwind CSS
- **Backend**: LocalStorage-based data persistence
- **Authentication**: Custom authentication system
- **File Storage**: Document metadata in localStorage
- **Theme**: Maharashtra Government branding with tricolor elements

## Key Features

### 🏠 Public Homepage
- **Attractive Landing Page** with slideshow featuring:
  - India Flag & Tricolor Theme
  - Maharashtra Government branding
  - "सत्यमेव जयते" (Satyamev Jayate) motto
  - Gateway of India and government building imagery
- **Features Section**: Highlighting benefits of online certificate issuance
- **How It Works**: Step-by-step guide for citizens
- **Navigation**: Login/Register button to access the system

### 👮 Admin Dashboard
#### Features:
- **Real-time Application Monitoring** (auto-refresh every 5 seconds)
- **Officer Management** - Complete CRUD operations:
  - Add new officers with district and taluk assignment
  - Edit officer details
  - Delete officers (auto-unassigns their applications)
  - View officer workload
- **Application Assignment**: Assign pending applications to officers
- **Statistics Dashboard**: Total, pending, approved, and rejected applications
- **User Management**: View all officers and citizens

#### Pre-configured Admin Account:
- Email: `admin@revenue.gov.in`
- Password: `admin123`

### 👔 Officer Dashboard
#### Features:
- View all assigned applications
- Review application details and documents
- Approve or reject applications with remarks
- Download approved certificates
- Track personal statistics

#### Pre-configured Officer Accounts:
1. **Rajesh Kumar**
   - Email: `officer1@revenue.gov.in`
   - Password: `officer123`
   - District: Mumbai City, Taluk A

2. **Priya Sharma**
   - Email: `officer2@revenue.gov.in`
   - Password: `officer123`
   - District: Pune, Taluk B

3. **Amit Patil**
   - Email: `officer3@revenue.gov.in`
   - Password: `officer123`
   - District: Nagpur, Taluk C

### 👤 Citizen Portal
#### Features:
- Self-registration with detailed information
- Apply for new caste certificate
- Upload multiple documents (Aadhaar, Birth Certificate, etc.)
- Track application status in real-time
- Download approved certificates
- View rejection reasons if applicable

#### Application Form Fields:
- Applicant Name
- Father's Name
- Date of Birth
- Caste Category (SC/ST/OBC/NT)
- Phone Number
- **Aadhaar Number** (required for certificate)
- District
- Residential Address
- Document Uploads

## Certificate Features

### Maharashtra Government Certificate
The generated certificates include:
- **Maharashtra branding** with tricolor border
- **"महाराष्ट्र शासन" and "Government of Maharashtra"** headers
- **"सत्यमेव जयते"** motto
- Official seal with Maharashtra emblem
- Complete applicant details:
  - Full name
  - Father's name
  - Date of birth
  - Caste category
  - Address
  - Contact number
  - **Aadhaar number** (last 4 digits for security)
  - District
- Certificate number format: `MH/RC/XXXXXXXX/2025`
- Issue date
- Authorized signatory details
- Verification URL
- Printable PDF format

## Application Workflow

1. **Citizen Applies**: 
   - Registers/Logs in
   - Fills detailed application form
   - Uploads required documents
   - Provides Aadhaar number
   - Status: `Pending`

2. **Admin Assigns**:
   - Reviews pending applications
   - Assigns to appropriate officer based on district/taluk
   - Status: `Under Review`

3. **Officer Reviews**:
   - Reviews application and documents
   - Verifies Aadhaar and other details
   - Approves with remarks OR rejects with reason
   - Status: `Approved` or `Rejected`

4. **Citizen Downloads**:
   - If approved, downloads official certificate
   - Certificate includes all verified details including Aadhaar

## Design Features

### Maharashtra Government Theme
- **Tricolor Elements**: Orange, White, and Green throughout the application
- **Background Images**: Gateway of India, government buildings on login/register pages
- **Official Branding**: Maharashtra Government logo and emblem
- **Hindi/Marathi Text**: Bilingual support (महाराष्ट्र शासन, सत्यमेव जयते)

### User Experience
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Smooth Navigation**: Home → Login → Dashboard flow
- **Visual Feedback**: Toast notifications for all actions
- **Real-time Updates**: Auto-refresh on admin dashboard
- **Professional UI**: Clean, government-standard interface

## Districts Supported
- Mumbai City
- Mumbai Suburban
- Pune
- Nagpur
- Thane
- Nashik
- Aurangabad
- Solapur
- Kolhapur
- Ahmednagar
- Amravati
- Sangli

## Security Features
- Password-based authentication
- Role-based access control
- Admin and Officer accounts managed by admin
- Aadhaar number masked in certificate (last 4 digits shown)
- Session management

## Quick Start Guide

### For Citizens:
1. Visit the homepage
2. Click "Login / Register"
3. Register with your details
4. Login and apply for certificate
5. Upload required documents including Aadhaar
6. Track application status
7. Download certificate when approved

### For Officers:
1. Login with officer credentials
2. View assigned applications
3. Review documents and details
4. Approve or reject with remarks
5. Download approved certificates

### For Admin:
1. Login with admin credentials
2. Switch to "Manage Officers" tab to:
   - Add new officers
   - Edit officer details
   - Delete officers
3. Switch to "Dashboard" tab to:
   - Monitor all applications
   - Assign applications to officers
   - View statistics

## Data Storage

### LocalStorage Schema:
- **users**: All user accounts (admin, officers, citizens)
- **applications**: All certificate applications
- **currentUser**: Active logged-in user session

### User Object:
```javascript
{
  id: string,
  name: string,
  email: string,
  password: string,
  role: 'admin' | 'officer' | 'citizen',
  phone: string,
  district: string,
  taluk?: string,  // For officers
  address?: string, // For citizens
  dateOfBirth?: string // For citizens
}
```

### Application Object:
```javascript
{
  id: string,
  citizenId: string,
  applicantName: string,
  fatherName: string,
  dob: string,
  caste: string,
  address: string,
  phone: string,
  aadhaarNumber: string,
  district: string,
  documents: Array,
  status: 'pending' | 'under_review' | 'approved' | 'rejected',
  assignedTo?: string,
  remarks?: string,
  approvedBy?: string,
  approvedAt?: string,
  createdAt: string
}
```

## Technical Stack
- **React** 18+ with TypeScript
- **Tailwind CSS** v4 for styling
- **Shadcn UI** components
- **Lucide React** for icons
- **Sonner** for toast notifications
- **LocalStorage** for data persistence

## Future Enhancements (Not Implemented)
- Backend API integration with Supabase
- Email notifications
- SMS alerts
- Digital signatures
- Payment gateway
- Advanced search and filters
- Analytics dashboard
- Audit logs
- Document OCR for auto-filling Aadhaar details
- Multi-language support
- Mobile app

## Support Information
- **Helpline**: 1800-XXX-XXXX
- **Email**: support@maharashtra.gov.in
- **Timings**: 10:00 AM - 6:00 PM
- **Verification URL**: www.maharashtra.gov.in/verify

---

© 2025 Government of Maharashtra. All rights reserved.
