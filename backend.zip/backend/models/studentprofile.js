const mongoose = require('mongoose');

const studentProfileSchema = new mongoose.Schema({
    userId: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User', 
        required: true 
    },

    // Basic Details
    bio: { type: String, default: 'No bio available' },
    phone: { type: String, default: 'Not provided' },
    alternatePhone: { type: String, default: 'Not provided' },
    gender: { type: String, enum: ["Male", "Female", "Other","not provided"], default: 'not provided' },
    dateOfBirth: { type: Date, default: null }, // Default as null since dates should be user-provided
    nationality: { type: String, default: 'Not specified' },
    maritalStatus: { type: String, enum: ["Single", "Married", "Divorced"], default: 'Single' },
    
    // Address
    address: {
        street: { type: String, required: false },
        city: { type: String, required: false },
        state: { type: String, required: false },
        country: { type: String, required: false },
        zipCode: { type: String, required: false }
    },

    // Education Details
    education: [{
        institutionName: { type: String, required: false },
        degree: { type: String, required: false },
        fieldOfStudy: { type: String, required: false },
        startYear: { type: Number, required: false },
        endYear: { type: Number, required: false },
        gradeOrPercentage: { type: String, required: false }
    }],

    // Work Experience
    workExperience: [{
        companyName: { type: String, required: false },
        jobTitle: { type: String, required: false },
        employmentType: { type: String, enum: ["Full-Time", "Part-Time", "Internship", "Contract"], required: false },
        startDate: { type: Date, required: false },
        endDate: { type: Date, required: false },
        currentlyWorking: { type: Boolean, required: false },
        jobDescription: { type: String, required: false }
    }],

    // Skills
    skills: [{ type: String, required: false }],

    // Certifications
    certifications: [{
        title: { type: String, required: false },
        issuingOrganization: { type: String, required: false },
        issueDate: { type: Date, required: false },
        expiryDate: { type: Date, required: false },
        credentialID: { type: String, required: false },
        credentialURL: { type: String, required: false }
    }],

    // Projects
    projects: [{
        title: { type: String, required: false },
        description: { type: String, required: false },
        technologiesUsed: [{ type: String, required: false }],
        startDate: { type: Date, required: false },
        endDate: { type: Date, required: false },
        projectURL: { type: String, required: false }
    }],

    // Social Media & Portfolio Links
    socialLinks: {
        linkedin: { type: String, required: false },
        github: { type: String, required: false },
        portfolio: { type: String, required: false },
        twitter: { type: String, required: false },
        personalWebsite: { type: String, required: false }
    },

    // Resume
    resumeURL: { type: String, required: false },

    // Expected Salary
    expectedSalary: { type: String, required: false },

    // Job Preferences
    jobPreferences: {
        preferredJobTitle: { type: String, required: false },
        preferredJobLocation: [{ type: String, required: false }],
        preferredEmploymentType: { type: String, enum: ["Full-Time", "Part-Time", "Internship", "Contract"], required: false },
        noticePeriod: { type: String, required: false },
        relocateWillingness: { type: Boolean, required: false }
    }
}, { timestamps: true });

module.exports = mongoose.model('StudentProfile', studentProfileSchema);
