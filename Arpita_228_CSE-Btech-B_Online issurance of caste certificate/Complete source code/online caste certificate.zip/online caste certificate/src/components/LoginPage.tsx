import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { ShieldCheck, LogIn } from 'lucide-react';

interface LoginPageProps {
  onLogin: (user: any) => void;
  onSwitchToRegister: () => void;
}

export function LoginPage({ onLogin, onSwitchToRegister }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Get users from localStorage
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    // Find user
    const user = users.find((u: any) => u.email === email && u.password === password);

    if (user) {
      onLogin(user);
    } else {
      setError('Invalid email or password');
    }
  };

  // Quick login buttons for demo
  const quickLogin = (role: string) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    let user = users.find((u: any) => u.role === role);
    
    if (!user) {
      // Create default users if they don't exist
      const defaultUsers = [
        { id: '1', email: 'admin@revenue.gov.in', password: 'admin123', role: 'admin', name: 'Admin User' },
        { id: '2', email: 'officer1@revenue.gov.in', password: 'officer123', role: 'officer', name: 'Rajesh Kumar' },
        { id: '3', email: 'citizen@example.com', password: 'citizen123', role: 'citizen', name: 'John Doe' }
      ];
      localStorage.setItem('users', JSON.stringify(defaultUsers));
      user = defaultUsers.find((u: any) => u.role === role);
    }
    
    if (user) {
      onLogin(user);
    }
  };

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-4 relative"
      style={{
        backgroundImage: 'url(https://images.unsplash.com/photo-1680344427682-ccb4e98a4d0b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWhhcmFzaHRyYSUyMGdhdGV3YXklMjBpbmRpYXxlbnwxfHx8fDE3NjAwMTgwMTF8MA&ixlib=rb-4.1.0&q=80&w=1080)',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-orange-900/70 via-white/60 to-green-900/70"></div>
      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8 bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-lg">
          <div className="bg-gradient-to-r from-orange-500 via-white to-green-600 h-2 mb-4 rounded"></div>
          <div className="flex items-center justify-center mb-4">
            <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center">
              <ShieldCheck className="h-12 w-12 text-white" />
            </div>
          </div>
          <h1 className="text-orange-700 mb-1">महाराष्ट्र शासन</h1>
          <h2 className="text-gray-800 mb-2">Government of Maharashtra</h2>
          <p className="text-gray-600">Revenue Department - Caste Certificate Portal</p>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm shadow-2xl">
          <CardHeader>
            <CardTitle>Login to Your Account</CardTitle>
            <CardDescription>Enter your credentials to access the system</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  disabled={loading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={loading}
                />
              </div>
              {error && (
                <div className="text-red-600 text-sm bg-red-50 p-3 rounded-md">{error}</div>
              )}
              <Button type="submit" className="w-full bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800">
                <LogIn className="mr-2 h-4 w-4" />
                Login
              </Button>
            </form>

            <div className="mt-6">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-gray-500">Demo Quick Login</span>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full" 
                  onClick={() => quickLogin('admin')}
                >
                  Login as Admin
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full" 
                  onClick={() => quickLogin('officer')}
                  disabled={loading}
                >
                  Login as Officer
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full" 
                  onClick={() => quickLogin('citizen')}
                >
                  Login as Citizen
                </Button>
              </div>
            </div>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                Don't have an account?{' '}
                <button
                  onClick={onSwitchToRegister}
                  className="text-orange-600 hover:underline"
                >
                  Register as Citizen
                </button>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}