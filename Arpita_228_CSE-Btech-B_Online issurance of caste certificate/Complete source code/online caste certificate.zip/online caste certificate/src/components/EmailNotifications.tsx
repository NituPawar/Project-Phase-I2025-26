import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Mail, Eye, CheckCircle, XCircle } from 'lucide-react';
import { getAllEmails } from '../utils/emailService';

export function EmailNotifications() {
  const [emails, setEmails] = useState<any[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<any>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    loadEmails();
    // Refresh every 5 seconds
    const interval = setInterval(loadEmails, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadEmails = () => {
    const allEmails = getAllEmails();
    setEmails(allEmails.reverse()); // Show newest first
  };

  const viewEmail = (email: any) => {
    setSelectedEmail(email);
    setDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl text-gray-900">Email Notifications</h2>
        <p className="text-sm text-gray-600">All email notifications sent to citizens</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-orange-600" />
            Sent Emails
          </CardTitle>
          <CardDescription>
            Total Emails Sent: {emails.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>To</TableHead>
                  <TableHead>Application ID</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {emails.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-gray-500">
                      No emails sent yet
                    </TableCell>
                  </TableRow>
                ) : (
                  emails.map((email, index) => (
                    <TableRow key={index}>
                      <TableCell className="text-sm">
                        {new Date(email.sentAt).toLocaleString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </TableCell>
                      <TableCell className="text-sm">{email.to}</TableCell>
                      <TableCell className="font-mono text-xs">#{email.applicationId.slice(0, 8)}</TableCell>
                      <TableCell>
                        {email.status === 'approved' ? (
                          <Badge className="bg-green-500">
                            <CheckCircle className="mr-1 h-3 w-3" />
                            Approved
                          </Badge>
                        ) : (
                          <Badge variant="destructive">
                            <XCircle className="mr-1 h-3 w-3" />
                            Rejected
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-sm max-w-xs truncate">{email.subject}</TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => viewEmail(email)}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* View Email Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Email Details</DialogTitle>
            <DialogDescription>
              Email notification sent to citizen
            </DialogDescription>
          </DialogHeader>
          {selectedEmail && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-xs text-gray-500">To</p>
                  <p className="text-sm">{selectedEmail.to}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Sent At</p>
                  <p className="text-sm">
                    {new Date(selectedEmail.sentAt).toLocaleString('en-IN', {
                      day: '2-digit',
                      month: 'long',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Application ID</p>
                  <p className="text-sm font-mono">#{selectedEmail.applicationId.slice(0, 8)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Status</p>
                  <div className="mt-1">
                    {selectedEmail.status === 'approved' ? (
                      <Badge className="bg-green-500">
                        <CheckCircle className="mr-1 h-3 w-3" />
                        Approved
                      </Badge>
                    ) : (
                      <Badge variant="destructive">
                        <XCircle className="mr-1 h-3 w-3" />
                        Rejected
                      </Badge>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-700 mb-2">Subject:</p>
                <p className="text-sm p-3 bg-blue-50 rounded">{selectedEmail.subject}</p>
              </div>

              <div>
                <p className="text-sm text-gray-700 mb-2">Email Content:</p>
                <div className="p-4 bg-white border rounded-lg">
                  <pre className="text-sm whitespace-pre-wrap font-sans">{selectedEmail.content}</pre>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
