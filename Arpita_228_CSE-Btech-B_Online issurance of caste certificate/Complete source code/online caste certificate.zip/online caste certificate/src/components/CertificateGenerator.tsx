export function generateCertificate(application: any) {
  // Create a new window for the certificate
  const certificateWindow = window.open('', '_blank');
  
  if (!certificateWindow) {
    alert('Please allow popups to download the certificate');
    return;
  }

  const certificateHTML = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Caste Certificate - Maharashtra Government</title>
      <style>
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        body {
          font-family: 'Times New Roman', serif;
          padding: 40px;
          background: #f5f5f5;
        }
        
        .certificate-container {
          max-width: 800px;
          margin: 0 auto;
          background: white;
          padding: 60px;
          border: 10px solid transparent;
          border-image: linear-gradient(to bottom, #ea580c 0%, white 33%, white 66%, #16a34a 100%) 1;
          box-shadow: 0 0 30px rgba(0,0,0,0.15);
          position: relative;
        }

        .tricolor-border-top {
          position: absolute;
          top: 10px;
          left: 10px;
          right: 10px;
          height: 6px;
          background: linear-gradient(to right, #ea580c 33%, white 33%, white 66%, #16a34a 66%);
        }

        .tricolor-border-bottom {
          position: absolute;
          bottom: 10px;
          left: 10px;
          right: 10px;
          height: 6px;
          background: linear-gradient(to right, #ea580c 33%, white 33%, white 66%, #16a34a 66%);
        }
        
        .header {
          text-align: center;
          margin-bottom: 40px;
          padding-bottom: 20px;
          border-bottom: 3px solid #ea580c;
        }
        
        .govt-logo {
          width: 80px;
          height: 80px;
          margin: 0 auto 20px;
          background: linear-gradient(135deg, #ea580c 0%, #f97316 100%);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 36px;
          font-weight: bold;
          box-shadow: 0 4px 10px rgba(234, 88, 12, 0.3);
        }
        
        .header h1 {
          color: #ea580c;
          font-size: 32px;
          margin-bottom: 5px;
        }
        
        .header h2 {
          color: #4b5563;
          font-size: 24px;
          margin-bottom: 5px;
        }

        .header h3 {
          color: #6b7280;
          font-size: 18px;
          margin-bottom: 10px;
          font-weight: normal;
        }
        
        .header .motto {
          color: #ea580c;
          font-size: 18px;
          font-style: italic;
          margin-top: 10px;
          font-weight: 600;
        }
        
        .certificate-title {
          text-align: center;
          margin: 30px 0;
          padding: 15px;
          background: linear-gradient(to right, #fff7ed, #ffedd5, #fff7ed);
          border-left: 5px solid #ea580c;
          border-right: 5px solid #16a34a;
        }
        
        .certificate-title h3 {
          color: #ea580c;
          font-size: 28px;
          text-transform: uppercase;
          letter-spacing: 2px;
        }
        
        .certificate-no {
          text-align: right;
          margin-bottom: 30px;
          font-size: 14px;
          color: #4b5563;
        }
        
        .content {
          line-height: 2;
          font-size: 16px;
          color: #1f2937;
          margin-bottom: 40px;
          text-align: justify;
        }
        
        .detail-row {
          display: flex;
          margin: 15px 0;
          padding: 12px;
          background: #f9fafb;
          border-left: 3px solid #ea580c;
          border-radius: 4px;
        }
        
        .detail-label {
          font-weight: bold;
          width: 220px;
          color: #ea580c;
        }
        
        .detail-value {
          flex: 1;
          color: #1f2937;
        }
        
        .footer {
          margin-top: 60px;
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
        }
        
        .signature-section {
          text-align: center;
        }
        
        .signature-line {
          width: 200px;
          border-top: 2px solid #1f2937;
          margin-top: 60px;
          padding-top: 10px;
        }
        
        .seal {
          width: 120px;
          height: 120px;
          border: 3px dashed #ea580c;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          color: #ea580c;
          text-align: center;
          padding: 10px;
          font-weight: bold;
          background: linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%);
        }
        
        .validity {
          margin-top: 30px;
          padding: 15px;
          background: #fef3c7;
          border: 2px solid #f59e0b;
          border-radius: 5px;
          text-align: center;
          font-size: 14px;
          color: #92400e;
        }
        
        .print-button {
          position: fixed;
          top: 20px;
          right: 20px;
          padding: 12px 24px;
          background: linear-gradient(135deg, #ea580c 0%, #f97316 100%);
          color: white;
          border: none;
          border-radius: 5px;
          cursor: pointer;
          font-size: 16px;
          box-shadow: 0 2px 10px rgba(234, 88, 12, 0.3);
        }
        
        .print-button:hover {
          background: linear-gradient(135deg, #dc2626 0%, #ea580c 100%);
          box-shadow: 0 4px 15px rgba(234, 88, 12, 0.5);
        }
        
        @media print {
          body {
            padding: 0;
            background: white;
          }
          
          .print-button {
            display: none;
          }
          
          .certificate-container {
            box-shadow: none;
          }
        }
      </style>
    </head>
    <body>
      <button class="print-button" onclick="window.print()">🖨️ Print / Download PDF</button>
      
      <div class="certificate-container">
        <div class="tricolor-border-top"></div>
        <div class="tricolor-border-bottom"></div>

        <div class="header">
          <div class="govt-logo">🏛️</div>
          <h1>महाराष्ट्र शासन</h1>
          <h2>Government of Maharashtra</h2>
          <h3>Revenue Department - Caste Certificate Division</h3>
          <p class="motto">सत्यमेव जयते</p>
        </div>
        
        <div class="certificate-no">
          Certificate No: <strong>MH/RC/${application.id.slice(0, 8).toUpperCase()}/2025</strong><br>
          Date of Issue: <strong>${new Date(application.approvedAt || Date.now()).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })}</strong>
        </div>
        
        <div class="certificate-title">
          <h3>Caste Certificate</h3>
          <p style="font-size: 16px; margin-top: 5px; color: #6b7280;">जातीचा दाखला</p>
        </div>
        
        <div class="content">
          <p style="margin-bottom: 20px;">
            This is to certify that <strong>${application.applicantName}</strong>, 
            Son/Daughter of <strong>${application.fatherName}</strong>, 
            residing at <strong>${application.address}</strong>, 
            belongs to the <strong>${application.caste}</strong> caste which is recognized 
            as a Scheduled Caste/Scheduled Tribe/Other Backward Class under:
          </p>
          
          <div style="margin-left: 30px; margin-bottom: 20px;">
            <p>• The Constitution (Scheduled Castes) Order, 1950</p>
            <p>• The Constitution (Scheduled Tribes) Order, 1950</p>
            <p>• The Central List of Other Backward Classes</p>
          </div>
        </div>
        
        <div class="details">
          <div class="detail-row">
            <div class="detail-label">Full Name:</div>
            <div class="detail-value">${application.applicantName}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">Father's Name:</div>
            <div class="detail-value">${application.fatherName}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">Date of Birth:</div>
            <div class="detail-value">${new Date(application.dob).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">Caste Category:</div>
            <div class="detail-value">${application.caste}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">Residential Address:</div>
            <div class="detail-value">${application.address}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">Contact Number:</div>
            <div class="detail-value">${application.phone}</div>
          </div>
          ${application.aadhaarNumber ? `
          <div class="detail-row">
            <div class="detail-label">Aadhaar Number:</div>
            <div class="detail-value">XXXX XXXX ${application.aadhaarNumber.slice(-4)} (Last 4 digits)</div>
          </div>
          ` : ''}
          ${application.district ? `
          <div class="detail-row">
            <div class="detail-label">District:</div>
            <div class="detail-value">${application.district}</div>
          </div>
          ` : ''}
        </div>
        
        <div class="validity">
          <strong>Note:</strong> This certificate is valid for all purposes as per Government of Maharashtra regulations. 
          It should be produced along with other relevant documents wherever required.
        </div>
        
        <div class="footer">
          <div class="seal">
            OFFICIAL SEAL
            <br><br>
            महाराष्ट्र शासन
            <br>
            Revenue Dept.
          </div>
          
          <div class="signature-section">
            <div class="signature-line">
              <div style="margin-top: 10px; font-weight: bold;">${application.approvedBy || 'Revenue Officer'}</div>
              <div style="font-size: 14px; color: #6b7280;">Authorized Signatory</div>
              <div style="font-size: 14px; color: #6b7280;">Revenue Department</div>
              <div style="font-size: 14px; color: #6b7280;">Government of Maharashtra</div>
            </div>
          </div>
        </div>
        
        <div style="margin-top: 40px; padding-top: 20px; border-top: 2px solid #e5e7eb; text-align: center; font-size: 12px; color: #6b7280;">
          This is a computer-generated certificate issued by Government of Maharashtra and is valid without physical signature and seal.
          <br>For verification, please visit: <strong>www.maharashtra.gov.in/verify</strong>
          <br>Certificate ID: <strong>${application.id}</strong> | Issue Date: <strong>${new Date(application.approvedAt || Date.now()).toLocaleDateString('en-IN')}</strong>
        </div>
      </div>
    </body>
    </html>
  `;

  certificateWindow.document.write(certificateHTML);
  certificateWindow.document.close();
}
