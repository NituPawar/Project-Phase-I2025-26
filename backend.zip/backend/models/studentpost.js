const mongoose = require("mongoose");

const studentPostSchema = new mongoose.Schema(
  {
    studentEmail: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      index: true,  // Indexing for faster queries
    },
    title: {
      type: String,
      trim: true,
      maxlength: 200,
    },
    description: {
      type: String,
      trim: true,
      maxlength: 5000,
    },
    files: [
      {
        url: { type: String, required: true }, // Cloudinary or external storage URL
        public_id: { type: String, required: true }, // Cloudinary unique ID
        fileType: { type: String, enum: ["image", "video", "pdf", "link"], required: true },
      },
    ],
    hashtags: {
      type: [String],
      default: [],
    },
    mentions: [{ type: String, lowercase: true }],
    postType: {
      type: String,
      enum: ["achievement", "event", "poll", "update"],
      default: "update",
    },
    privacy: {
      type: String,
      enum: ["public", "private", "connections"],
      default: "public",
    },
    likes: [{ type: String, lowercase: true }],
    reactions: [
      {
        userEmail: { type: String, lowercase: true },
        type: {
          type: String,
          enum: ["like", "love", "celebrate", "insightful"],
        },
      },
    ],
    comments: [
      {
        userEmail: { type: String, lowercase: true },
        text: { type: String, maxlength: 1000 },
        createdAt: { type: Date, default: Date.now },
      },
    ],
    shares: [{ type: String, lowercase: true }], // Emails of users who shared the post
     views: [{ type: String, lowercase: true }],
    polls: {
      question: { type: String, trim: true, maxlength: 300 },
      options: [
        {
          text: { type: String, maxlength: 100 },
          votes: { type: Number, default: 0 },
        },
      ],
      expiresAt: { type: Date },
    },
    event: {
      name: { type: String, trim: true },
      date: { type: Date },
      location: { type: String, trim: true },
      description: { type: String, trim: true, maxlength: 2000 },
      attendees: [{ type: String, lowercase: true }], // Store attendee emails
    },
    isPinned: { type: Boolean, default: false },
  },
  { timestamps: true }
);

// Indexing for faster queries
studentPostSchema.index({ createdAt: -1 });

const StudentPost = mongoose.model("StudentPost", studentPostSchema);
module.exports = StudentPost;
