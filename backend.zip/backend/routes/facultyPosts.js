const express = require("express");
const router = express.Router();
const FacultyPost = require("../models/facultypost");
const User = require("../models/user");
const multer = require("multer");
const cloudinary = require("cloudinary").v2;
const { CloudinaryStorage } = require("multer-storage-cloudinary");
require("dotenv").config();

// Configure Cloudinary
console.log("Configuring Cloudinary...");
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Multer Storage for Cloudinary
console.log("Setting up Multer storage...");
const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: "faculty_posts",
    allowed_formats: ["jpg", "png", "jpeg"],
  },
});
const upload = multer({ storage });


// Route: Create a new faculty post with image upload
router.post("/api/faculty-post", upload.array("images", 5), async (req, res) => {
  try {
    console.log("=== Received request to create a new faculty post ===");
    
    // Log the request body and files
    console.log("Request Body:", req.body);
    console.log("Uploaded Files:", req.files);

    const { faculty, title, description, department, researchArea, contactEmail, hashtags,postedBy ,pinned} = req.body;

    console.log("Validating request fields...");
    
    console.log("Validation passed.");

    // Extract Cloudinary URLs from uploaded images
     // Extract and structure image data
     const imageUrls = req.files.map(file => ({
        url: file.path, // Cloudinary URL
        public_id: file.filename, // Unique ID assigned by Cloudinary
        fileType: file.mimetype // Store file type
      }));
    console.log("Extracted Image URLs:", imageUrls);

    // Creating the new faculty post object
    const newPost = new FacultyPost({
      faculty,
      title,
      description,
      department,
      researchArea: researchArea || "General",
      contactEmail,
      hashtags: hashtags ? hashtags.split(",").map(tag => tag.trim()) : [],
      files: imageUrls,
      postedBy,
      pinned: pinned || false, // Default to false if not provided
      visibility: "Public",
    });
    

    console.log("Attempting to save the new post to the database...");
    await newPost.save();
    console.log("Post saved successfully:", newPost);

    res.status(201).json({ message: "Post created successfully", post: newPost });
  } catch (error) {
    console.error("Error during post creation:", error);
    res.status(500).json({ error: "Server error", details: error.message });
  }
});

// Route: Get all faculty posts
router.get("/api/faculty-posts", async (req, res) => {
  try {
    console.log("=== Fetching all faculty posts from the database ===");

    // Step 1: Fetch all posts (postedBy is an email string here)
    const posts = await FacultyPost.find().sort({ createdAt: -1 });

    // Step 2: Extract all unique emails from posts
    const postedByEmails = [...new Set(posts.map(post => post.postedBy))];

    // Step 3: Fetch all users whose email is in postedByEmails
    const users = await User.find({ email: { $in: postedByEmails } });

    // Step 4: Create a map of email -> user data for quick lookup
    const userMap = {};
    users.forEach(user => {
      userMap[user.email] = {
        fullname: user.fullname,
        email: user.email,
        profileImageUrl: user.profileImageUrl,
        role: user.role
      };
    });
console.log("User Map:", userMap);
    // Step 5: Map posts and attach `createdBy` field using email
    const enrichedPosts = posts.map(post => {
      const userDetails = userMap[post.postedBy] || {};
      return {
        ...post.toObject(),
        createdBy: userDetails
      };
    });
 console.log("Enriched Posts:", enrichedPosts);
    res.status(200).json(enrichedPosts);
  } catch (error) {
    console.error("Error fetching posts:", error);
    res.status(500).json({ error: "Server error", details: error.message });
  }
});

module.exports = router;
