import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Initialize default users (admin and officers)
async function initializeDefaultUsers() {
  const existingUsers = await kv.get("initialized");
  
  if (!existingUsers) {
    // Create admin account
    const admin = {
      id: "admin_1",
      email: "admin@revenue.gov.in",
      password: "admin123",
      role: "admin",
      name: "System Administrator",
      createdAt: new Date().toISOString(),
    };
    
    // Create officer accounts
    const officers = [
      {
        id: "officer_1",
        email: "officer1@revenue.gov.in",
        password: "officer123",
        role: "officer",
        name: "Rajesh Kumar",
        district: "District 1",
        taluk: "Taluk A",
        assignedApplications: 0,
        createdAt: new Date().toISOString(),
      },
      {
        id: "officer_2",
        email: "officer2@revenue.gov.in",
        password: "officer123",
        role: "officer",
        name: "Priya Sharma",
        district: "District 2",
        taluk: "Taluk B",
        assignedApplications: 0,
        createdAt: new Date().toISOString(),
      },
      {
        id: "officer_3",
        email: "officer3@revenue.gov.in",
        password: "officer123",
        role: "officer",
        name: "Amit Patel",
        district: "District 1",
        taluk: "Taluk C",
        assignedApplications: 0,
        createdAt: new Date().toISOString(),
      },
    ];
    
    await kv.set(`user:${admin.id}`, admin);
    await kv.set(`user:email:${admin.email}`, admin.id);
    
    for (const officer of officers) {
      await kv.set(`user:${officer.id}`, officer);
      await kv.set(`user:email:${officer.email}`, officer.id);
    }
    
    await kv.set("initialized", "true");
    console.log("Default users initialized");
  }
}

// Initialize on startup
initializeDefaultUsers();

// Health check endpoint
app.get("/make-server-27aaa517/health", (c) => {
  return c.json({ status: "ok" });
});

// Auth Routes
app.post("/make-server-27aaa517/auth/login", async (c) => {
  try {
    const { email, password } = await c.req.json();
    
    if (!email || !password) {
      return c.json({ error: "Email and password are required" }, 400);
    }
    
    // Get user ID from email
    const userId = await kv.get(`user:email:${email}`);
    
    if (!userId) {
      return c.json({ error: "Invalid email or password" }, 401);
    }
    
    // Get user details
    const user = await kv.get(`user:${userId}`);
    
    if (!user || user.password !== password) {
      return c.json({ error: "Invalid email or password" }, 401);
    }
    
    // Don't send password back to client
    const { password: _, ...userWithoutPassword } = user;
    
    return c.json({ user: userWithoutPassword });
  } catch (error) {
    console.log("Login error:", error);
    return c.json({ error: "Login failed" }, 500);
  }
});

app.post("/make-server-27aaa517/auth/register", async (c) => {
  try {
    const { email, password, name, phone, address, district, taluk, village } = await c.req.json();
    
    if (!email || !password || !name) {
      return c.json({ error: "Email, password, and name are required" }, 400);
    }
    
    // Check if user already exists
    const existingUserId = await kv.get(`user:email:${email}`);
    
    if (existingUserId) {
      return c.json({ error: "Email already registered" }, 400);
    }
    
    // Create new citizen user
    const userId = `citizen_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const user = {
      id: userId,
      email,
      password,
      role: "citizen",
      name,
      phone,
      address,
      district,
      taluk,
      village,
      createdAt: new Date().toISOString(),
    };
    
    await kv.set(`user:${userId}`, user);
    await kv.set(`user:email:${email}`, userId);
    
    const { password: _, ...userWithoutPassword } = user;
    
    return c.json({ user: userWithoutPassword });
  } catch (error) {
    console.log("Registration error:", error);
    return c.json({ error: "Registration failed" }, 500);
  }
});

// Application Routes
app.post("/make-server-27aaa517/applications", async (c) => {
  try {
    const applicationData = await c.req.json();
    
    const applicationId = `APP${Date.now()}${Math.floor(Math.random() * 1000)}`;
    
    const application = {
      ...applicationData,
      id: applicationId,
      status: "pending",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    await kv.set(`application:${applicationId}`, application);
    
    // Add to user's applications list
    const userApplications = await kv.get(`user:${applicationData.userId}:applications`) || [];
    userApplications.push(applicationId);
    await kv.set(`user:${applicationData.userId}:applications`, userApplications);
    
    return c.json({ application });
  } catch (error) {
    console.log("Create application error:", error);
    return c.json({ error: "Failed to create application" }, 500);
  }
});

app.get("/make-server-27aaa517/applications", async (c) => {
  try {
    const userId = c.req.query("userId");
    const role = c.req.query("role");
    
    if (!userId || !role) {
      return c.json({ error: "userId and role are required" }, 400);
    }
    
    let applications = [];
    
    if (role === "citizen") {
      const userApplicationIds = await kv.get(`user:${userId}:applications`) || [];
      const appPromises = userApplicationIds.map((id: string) => kv.get(`application:${id}`));
      applications = (await Promise.all(appPromises)).filter(Boolean);
    } else if (role === "officer") {
      const assignedIds = await kv.get(`officer:${userId}:assigned`) || [];
      const appPromises = assignedIds.map((id: string) => kv.get(`application:${id}`));
      applications = (await Promise.all(appPromises)).filter(Boolean);
    } else if (role === "admin") {
      // Get all applications for admin
      const allKeys = await kv.getByPrefix("application:");
      applications = allKeys.filter(app => app && app.id);
    }
    
    return c.json({ applications });
  } catch (error) {
    console.log("Get applications error:", error);
    return c.json({ error: "Failed to fetch applications" }, 500);
  }
});

app.get("/make-server-27aaa517/applications/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const application = await kv.get(`application:${id}`);
    
    if (!application) {
      return c.json({ error: "Application not found" }, 404);
    }
    
    return c.json({ application });
  } catch (error) {
    console.log("Get application error:", error);
    return c.json({ error: "Failed to fetch application" }, 500);
  }
});

app.put("/make-server-27aaa517/applications/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const updates = await c.req.json();
    
    const application = await kv.get(`application:${id}`);
    
    if (!application) {
      return c.json({ error: "Application not found" }, 404);
    }
    
    const updatedApplication = {
      ...application,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    
    await kv.set(`application:${id}`, updatedApplication);
    
    return c.json({ application: updatedApplication });
  } catch (error) {
    console.log("Update application error:", error);
    return c.json({ error: "Failed to update application" }, 500);
  }
});

// Assign application to officer
app.post("/make-server-27aaa517/applications/:id/assign", async (c) => {
  try {
    const applicationId = c.req.param("id");
    const { officerId } = await c.req.json();
    
    const application = await kv.get(`application:${applicationId}`);
    
    if (!application) {
      return c.json({ error: "Application not found" }, 404);
    }
    
    // Update application with officer assignment
    application.assignedTo = officerId;
    application.status = "under_review";
    application.updatedAt = new Date().toISOString();
    
    await kv.set(`application:${applicationId}`, application);
    
    // Add to officer's assigned list
    const officerAssigned = await kv.get(`officer:${officerId}:assigned`) || [];
    if (!officerAssigned.includes(applicationId)) {
      officerAssigned.push(applicationId);
      await kv.set(`officer:${officerId}:assigned`, officerAssigned);
    }
    
    // Update officer's assigned count
    const officer = await kv.get(`user:${officerId}`);
    if (officer) {
      officer.assignedApplications = (officer.assignedApplications || 0) + 1;
      await kv.set(`user:${officerId}`, officer);
    }
    
    return c.json({ application });
  } catch (error) {
    console.log("Assign application error:", error);
    return c.json({ error: "Failed to assign application" }, 500);
  }
});

// Get all officers
app.get("/make-server-27aaa517/officers", async (c) => {
  try {
    const allUsers = await kv.getByPrefix("user:");
    const officers = allUsers.filter((user: any) => user && user.role === "officer");
    
    // Remove passwords
    const officersWithoutPasswords = officers.map((officer: any) => {
      const { password, ...rest } = officer;
      return rest;
    });
    
    return c.json({ officers: officersWithoutPasswords });
  } catch (error) {
    console.log("Get officers error:", error);
    return c.json({ error: "Failed to fetch officers" }, 500);
  }
});

// Upload document
app.post("/make-server-27aaa517/documents", async (c) => {
  try {
    const { applicationId, fileName, fileData, fileType } = await c.req.json();
    
    const documentId = `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const document = {
      id: documentId,
      applicationId,
      fileName,
      fileData, // base64 encoded
      fileType,
      uploadedAt: new Date().toISOString(),
    };
    
    await kv.set(`document:${documentId}`, document);
    
    // Add to application's documents list
    const appDocuments = await kv.get(`application:${applicationId}:documents`) || [];
    appDocuments.push(documentId);
    await kv.set(`application:${applicationId}:documents`, appDocuments);
    
    return c.json({ document: { id: documentId, fileName, fileType, uploadedAt: document.uploadedAt } });
  } catch (error) {
    console.log("Upload document error:", error);
    return c.json({ error: "Failed to upload document" }, 500);
  }
});

// Get documents for an application
app.get("/make-server-27aaa517/applications/:id/documents", async (c) => {
  try {
    const applicationId = c.req.param("id");
    
    const documentIds = await kv.get(`application:${applicationId}:documents`) || [];
    const docPromises = documentIds.map((id: string) => kv.get(`document:${id}`));
    const documents = (await Promise.all(docPromises)).filter(Boolean);
    
    return c.json({ documents });
  } catch (error) {
    console.log("Get documents error:", error);
    return c.json({ error: "Failed to fetch documents" }, 500);
  }
});

// Get statistics for admin dashboard
app.get("/make-server-27aaa517/stats", async (c) => {
  try {
    const allApplications = await kv.getByPrefix("application:");
    const allOfficers = await kv.getByPrefix("user:");
    const officers = allOfficers.filter((user: any) => user && user.role === "officer");
    const citizens = allOfficers.filter((user: any) => user && user.role === "citizen");
    
    const stats = {
      totalApplications: allApplications.length,
      pendingApplications: allApplications.filter((app: any) => app && app.status === "pending").length,
      underReviewApplications: allApplications.filter((app: any) => app && app.status === "under_review").length,
      approvedApplications: allApplications.filter((app: any) => app && app.status === "approved").length,
      rejectedApplications: allApplications.filter((app: any) => app && app.status === "rejected").length,
      totalOfficers: officers.length,
      totalCitizens: citizens.length,
    };
    
    return c.json({ stats });
  } catch (error) {
    console.log("Get stats error:", error);
    return c.json({ error: "Failed to fetch statistics" }, 500);
  }
});

// Send email notification using SendGrid
app.post("/make-server-27aaa517/send-email", async (c) => {
  try {
    const { to, subject, html, text } = await c.req.json();
    
    if (!to || !subject || !html) {
      return c.json({ error: "Missing required fields: to, subject, html" }, 400);
    }
    
    // Get SendGrid API key from environment
    const sendGridApiKey = Deno.env.get("SENDGRID_API_KEY");
    
    if (!sendGridApiKey) {
      console.log("Warning: SENDGRID_API_KEY not configured. Email will be logged but not sent.");
      console.log("📧 EMAIL NOTIFICATION:");
      console.log("To:", to);
      console.log("Subject:", subject);
      console.log("Content:", text || html);
      
      // Store email in KV for admin viewing
      const emailId = `email_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await kv.set(`email:${emailId}`, {
        id: emailId,
        to,
        subject,
        html,
        text,
        sentAt: new Date().toISOString(),
        status: "simulated"
      });
      
      return c.json({ 
        success: true, 
        message: "Email logged (SendGrid not configured). Configure SENDGRID_API_KEY to send real emails.",
        emailId 
      });
    }
    
    // Send email via SendGrid API
    const sendGridResponse = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${sendGridApiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        personalizations: [{
          to: [{ email: to }]
        }],
        from: {
          email: "noreply@maharashtra.gov.in",
          name: "Maharashtra Government - Revenue Department"
        },
        subject: subject,
        content: [
          {
            type: "text/plain",
            value: text || html
          },
          {
            type: "text/html",
            value: html
          }
        ]
      })
    });
    
    if (!sendGridResponse.ok) {
      const errorText = await sendGridResponse.text();
      console.error("SendGrid API error:", errorText);
      throw new Error(`SendGrid API error: ${sendGridResponse.status}`);
    }
    
    // Store email in KV for admin viewing
    const emailId = `email_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    await kv.set(`email:${emailId}`, {
      id: emailId,
      to,
      subject,
      html,
      text,
      sentAt: new Date().toISOString(),
      status: "sent"
    });
    
    console.log(`✅ Email sent successfully to ${to}`);
    
    return c.json({ 
      success: true, 
      message: "Email sent successfully",
      emailId 
    });
  } catch (error) {
    console.error("Send email error:", error);
    return c.json({ 
      error: "Failed to send email", 
      details: error instanceof Error ? error.message : "Unknown error" 
    }, 500);
  }
});

// Get all sent emails (for admin)
app.get("/make-server-27aaa517/emails", async (c) => {
  try {
    const emails = await kv.getByPrefix("email:");
    const sortedEmails = emails.sort((a: any, b: any) => {
      return new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime();
    });
    
    return c.json({ emails: sortedEmails });
  } catch (error) {
    console.log("Get emails error:", error);
    return c.json({ error: "Failed to fetch emails" }, 500);
  }
});

Deno.serve(app.fetch);
