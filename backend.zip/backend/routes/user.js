const express = require("express");
const mongoose = require("mongoose");
const User = require("../models/user");
const StudentProfile = require("../models/studentprofile");
const FacultyProfile = require("../models/facultyprofile");
const AlumniProfile = require("../models/alumniprofile");
const cloudinary = require("cloudinary").v2;
const router = express.Router();

// ✅ Route: Render Sign-in Page
router.get("/signin", (req, res) => {
    res.render("signin");
});

// ✅ Route: Render Sign-up Page
router.get("/signup", (req, res) => {
    res.render("signup");
});

// ✅ Sign-in Route
router.post("/signin", async (req, res) => {
    const { email, password } = req.body;

    try {
        // Check if user exists
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(401).json({ success: false, message: "Invalid email or password" });
        }

        // Verify password and generate token
        const token = await User.matchPasswordAndGenerateToken(email, password);
        console.log("Token generated:", token);

        // Set HTTP-only cookie for security
        res.cookie("token", token, {
            httpOnly: true,
            maxAge: 60 * 60 * 1000, // 1 hour
        });

        res.json({
            success: true,
            message: "Login successful",
            user: {
                _id: user._id,
                fullname: user.fullname,
                email: user.email,
                role: user.role,
                profileImageUrl: user.profileImageUrl || "", // Default empty if no image
                createdAt: user.createdAt,
            },
        });
    } catch (error) {
        console.error("Error during sign-in:", error.message);
        res.status(500).json({ success: false, message: "Internal server error" });
    }
});

// ✅ Sign-up Route
router.post("/signup", async (req, res) => {
    const { fullname, email, password, role } = req.body;

    try {
        // Validate role
        if (!["Student", "Faculty", "Alumni"].includes(role)) {
            return res.status(400).json({ error: "Invalid role. Allowed values: Student, Faculty, Alumni" });
        }

        // Check if email is already registered
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: "Email is already registered" });
        }

        // Create new user
        const newUser = await User.create({ fullname, email, password, role });

        // Create associated profile based on role
        if (role === "Student") {
            await StudentProfile.create({ userId: newUser._id });
            console.log("Student profile created successfully");
        } else if (role === "Faculty") {
            await FacultyProfile.create({ userId: newUser._id });
        } else if (role === "Alumni") {
            await AlumniProfile.create({ userId: newUser._id });
        }

        console.log("User registered successfully:", newUser);
        res.status(201).json({ message: "User registered successfully", user: newUser });
    } catch (error) {
        console.error("Error creating user:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// ✅ Update Profile (Cloudinary Image Upload Support)
router.put("/update-profile/:id", async (req, res) => {
    try {
        const { fullname, profileImageBase64 } = req.body;
        const { id: userId } = req.params;

        // Validate ObjectId
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ message: "Invalid User ID" });
        }

        let profileImageUrl = null;

        // Upload image to Cloudinary if provided
        if (profileImageBase64) {
            try {
                const uploadResponse = await cloudinary.uploader.upload(profileImageBase64, {
                    folder: "profile_pictures",
                    transformation: [{ width: 300, height: 300, crop: "fill" }],
                });
                profileImageUrl = uploadResponse.secure_url;
            } catch (uploadError) {
                console.error("Cloudinary upload error:", uploadError.message);
                return res.status(500).json({ message: "Image upload failed", error: uploadError.message });
            }
        }

        // Update user in the database
        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { fullname, ...(profileImageUrl && { profileImageUrl }) },
            { new: true, runValidators: true }
        );

        if (!updatedUser) {
            return res.status(404).json({ message: "User not found" });
        }

        res.status(200).json({ message: "Profile updated successfully", user: updatedUser });
    } catch (error) {
        console.error("Error updating profile:", error.message);
        res.status(500).json({ message: "Server error", error: error.message });
    }
});

// Route to fetch student profile by email


module.exports = router;
