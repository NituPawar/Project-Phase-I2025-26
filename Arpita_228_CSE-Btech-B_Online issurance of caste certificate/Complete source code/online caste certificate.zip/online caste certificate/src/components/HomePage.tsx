import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Shield, FileText, Clock, Award, ChevronLeft, ChevronRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HomePageProps {
  onLoginClick: () => void;
}

export function HomePage({ onLoginClick }: HomePageProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      image: 'https://images.unsplash.com/photo-1692985300056-a021e5a5386d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYSUyMGZsYWclMjB0cmljb2xvcnxlbnwxfHx8fDE3NjAwMTgwMTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Digital India Initiative',
      description: 'Empowering citizens through digital governance'
    },
    {
      image: 'https://images.unsplash.com/photo-1680344427682-ccb4e98a4d0b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWhhcmFzaHRyYSUyMGdhdGV3YXklMjBpbmRpYXxlbnwxfHx8fDE3NjAwMTgwMTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Maharashtra Government',
      description: 'Serving the people with transparency and efficiency'
    },
    {
      image: 'https://images.unsplash.com/photo-1722850794648-b411ad2936bf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwaW5kaWElMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2MDAxODAxMnww&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'e-Governance Services',
      description: 'Fast, transparent, and accessible to all'
    },
    {
      image: 'https://images.unsplash.com/photo-1709967884183-7ffa9d168508?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3Zlcm5tZW50JTIwYnVpbGRpbmclMjBpbmRpYXxlbnwxfHx8fDE3NTk5ODQ3MDh8MA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Revenue Department',
      description: 'Streamlined certificate issuance process'
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50">
      {/* Header with Flag Colors */}
      <div className="bg-gradient-to-r from-orange-500 via-white to-green-600 h-2"></div>
      
      {/* Top Bar */}
      <div className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center">
                <Shield className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-orange-700 text-2xl">महाराष्ट्र शासन</h1>
                <h2 className="text-gray-700">Government of Maharashtra</h2>
                <p className="text-sm text-gray-600">Revenue Department - Caste Certificate Division</p>
              </div>
            </div>
            <Button 
              onClick={onLoginClick} 
              size="lg"
              className="bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800"
            >
              Login / Register
            </Button>
          </div>
        </div>
      </div>

      {/* Satyamev Jayate Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 text-white py-3">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
              <Award className="h-6 w-6 text-yellow-300" />
            </div>
            <div>
              <h3 className="text-2xl font-serif">सत्यमेव जयते</h3>
              <p className="text-sm text-blue-200">Truth Alone Triumphs</p>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Slideshow Section */}
      <div className="relative h-[500px] overflow-hidden bg-black">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <ImageWithFallback
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent"></div>
            <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
              <div className="container mx-auto">
                <h2 className="text-4xl mb-2">{slide.title}</h2>
                <p className="text-xl text-gray-200">{slide.description}</p>
              </div>
            </div>
          </div>
        ))}
        
        {/* Slideshow Controls */}
        <button
          onClick={prevSlide}
          className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/30 hover:bg-white/50 text-white p-3 rounded-full transition-all"
        >
          <ChevronLeft className="h-6 w-6" />
        </button>
        <button
          onClick={nextSlide}
          className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/30 hover:bg-white/50 text-white p-3 rounded-full transition-all"
        >
          <ChevronRight className="h-6 w-6" />
        </button>

        {/* Slide Indicators */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide ? 'bg-white w-8' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl text-gray-800 mb-4">Online Caste Certificate Issuance System</h2>
          <p className="text-lg text-gray-600">Fast, Transparent, and Paperless Certificate Services</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-t-4 border-t-orange-500 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                <FileText className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-center text-gray-800 mb-2">Easy Application</h3>
              <p className="text-center text-sm text-gray-600">
                Apply online from anywhere with required documents
              </p>
            </CardContent>
          </Card>

          <Card className="border-t-4 border-t-blue-500 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                <Clock className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-center text-gray-800 mb-2">Quick Processing</h3>
              <p className="text-center text-sm text-gray-600">
                Get your certificate processed within 7 working days
              </p>
            </CardContent>
          </Card>

          <Card className="border-t-4 border-t-green-500 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                <Shield className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-center text-gray-800 mb-2">Secure & Verified</h3>
              <p className="text-center text-sm text-gray-600">
                All certificates are digitally signed and verified
              </p>
            </CardContent>
          </Card>

          <Card className="border-t-4 border-t-purple-500 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                <Award className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-center text-gray-800 mb-2">Track Status</h3>
              <p className="text-center text-sm text-gray-600">
                Real-time tracking of your application status
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* How It Works Section */}
      <div className="bg-gradient-to-br from-orange-50 to-orange-100 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl text-center text-gray-800 mb-12">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-orange-600 text-white rounded-full flex items-center justify-center text-3xl mx-auto mb-4">
                1
              </div>
              <h3 className="text-gray-800 mb-2">Register & Login</h3>
              <p className="text-sm text-gray-600">Create your account with basic details</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-orange-600 text-white rounded-full flex items-center justify-center text-3xl mx-auto mb-4">
                2
              </div>
              <h3 className="text-gray-800 mb-2">Submit Application</h3>
              <p className="text-sm text-gray-600">Fill form and upload required documents</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-orange-600 text-white rounded-full flex items-center justify-center text-3xl mx-auto mb-4">
                3
              </div>
              <h3 className="text-gray-800 mb-2">Verification</h3>
              <p className="text-sm text-gray-600">Officer reviews and verifies documents</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-orange-600 text-white rounded-full flex items-center justify-center text-3xl mx-auto mb-4">
                4
              </div>
              <h3 className="text-gray-800 mb-2">Download Certificate</h3>
              <p className="text-sm text-gray-600">Get your approved certificate instantly</p>
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-gradient-to-r from-orange-600 to-orange-700 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl mb-4">Ready to Apply?</h2>
          <p className="text-xl mb-6 text-orange-100">
            Get your caste certificate issued online in just a few steps
          </p>
          <Button 
            onClick={onLoginClick}
            size="lg"
            className="bg-white text-orange-600 hover:bg-orange-50"
          >
            Get Started Now
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg mb-4">महाराष्ट्र शासन</h3>
              <p className="text-sm text-gray-400">
                Revenue Department<br />
                Government of Maharashtra<br />
                Mantralaya, Mumbai - 400032
              </p>
            </div>
            <div>
              <h3 className="text-lg mb-4">Quick Links</h3>
              <ul className="text-sm text-gray-400 space-y-2">
                <li>About Us</li>
                <li>Contact Support</li>
                <li>FAQs</li>
                <li>Download Forms</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg mb-4">Help & Support</h3>
              <p className="text-sm text-gray-400">
                Helpline: 1800-XXX-XXXX<br />
                Email: support@maharashtra.gov.in<br />
                Timings: 10:00 AM - 6:00 PM
              </p>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-6 text-center text-sm text-gray-400">
            <p>© 2025 Government of Maharashtra. All rights reserved.</p>
            <p className="mt-2">Best viewed in Chrome, Firefox, Safari & Edge</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
