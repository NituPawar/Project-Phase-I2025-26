import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { UserPlus, Edit, Trash2, UserCheck, Mail, Phone, MapPin } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Officer {
  id: string;
  name: string;
  email: string;
  password: string;
  phone: string;
  district: string;
  taluk: string;
  role: 'officer';
}

export function OfficerManagement() {
  const [officers, setOfficers] = useState<Officer[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingOfficer, setEditingOfficer] = useState<Officer | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    district: '',
    taluk: ''
  });

  const districts = [
    'Mumbai City', 'Mumbai Suburban', 'Pune', 'Nagpur', 'Thane', 'Nashik', 
    'Aurangabad', 'Solapur', 'Kolhapur', 'Ahmednagar', 'Amravati', 'Sangli'
  ];

  const taluks = [
    'Taluk A', 'Taluk B', 'Taluk C', 'Taluk D', 'Taluk E', 'Taluk F'
  ];

  useEffect(() => {
    loadOfficers();
  }, []);

  const loadOfficers = () => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const officerList = users.filter((u: any) => u.role === 'officer');
    setOfficers(officerList);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.email || !formData.phone || !formData.district || !formData.taluk) {
      toast.error('Please fill all required fields');
      return;
    }

    const users = JSON.parse(localStorage.getItem('users') || '[]');

    if (editingOfficer) {
      // Update existing officer
      const updatedUsers = users.map((u: any) => {
        if (u.id === editingOfficer.id) {
          return {
            ...u,
            ...formData,
            password: formData.password || u.password // Keep old password if not changed
          };
        }
        return u;
      });
      localStorage.setItem('users', JSON.stringify(updatedUsers));
      toast.success('Officer updated successfully');
    } else {
      // Check if email already exists
      if (users.some((u: any) => u.email === formData.email)) {
        toast.error('Email already exists');
        return;
      }

      // Add new officer
      const newOfficer: Officer = {
        id: Date.now().toString(),
        ...formData,
        password: formData.password || 'officer123',
        role: 'officer'
      };
      users.push(newOfficer);
      localStorage.setItem('users', JSON.stringify(users));
      toast.success('Officer added successfully');
    }

    loadOfficers();
    setDialogOpen(false);
    resetForm();
  };

  const handleEdit = (officer: Officer) => {
    setEditingOfficer(officer);
    setFormData({
      name: officer.name,
      email: officer.email,
      password: '',
      phone: officer.phone,
      district: officer.district,
      taluk: officer.taluk
    });
    setDialogOpen(true);
  };

  const handleDelete = (officerId: string) => {
    if (confirm('Are you sure you want to delete this officer? All assigned applications will be unassigned.')) {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const updatedUsers = users.filter((u: any) => u.id !== officerId);
      localStorage.setItem('users', JSON.stringify(updatedUsers));

      // Unassign all applications assigned to this officer
      const apps = JSON.parse(localStorage.getItem('applications') || '[]');
      const updatedApps = apps.map((app: any) => {
        if (app.assignedTo === officerId) {
          return { ...app, assignedTo: null, status: 'pending' };
        }
        return app;
      });
      localStorage.setItem('applications', JSON.stringify(updatedApps));

      loadOfficers();
      toast.success('Officer deleted successfully');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      password: '',
      phone: '',
      district: '',
      taluk: ''
    });
    setEditingOfficer(null);
  };

  const openAddDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl text-gray-900">Officer Management</h2>
          <p className="text-sm text-gray-600">Add, edit, or remove revenue officers</p>
        </div>
        <Button onClick={openAddDialog} className="bg-green-600 hover:bg-green-700">
          <UserPlus className="mr-2 h-4 w-4" />
          Add New Officer
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Registered Officers</CardTitle>
          <CardDescription>
            Total Officers: {officers.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>District</TableHead>
                  <TableHead>Taluk</TableHead>
                  <TableHead>Applications</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {officers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-gray-500">
                      No officers found. Click "Add New Officer" to get started.
                    </TableCell>
                  </TableRow>
                ) : (
                  officers.map((officer) => {
                    const apps = JSON.parse(localStorage.getItem('applications') || '[]');
                    const assignedCount = apps.filter((a: any) => a.assignedTo === officer.id).length;

                    return (
                      <TableRow key={officer.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <UserCheck className="h-4 w-4 text-blue-600" />
                            <span>{officer.name}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-sm">
                            <Mail className="h-3 w-3 text-gray-400" />
                            {officer.email}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-sm">
                            <Phone className="h-3 w-3 text-gray-400" />
                            {officer.phone}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-sm">
                            <MapPin className="h-3 w-3 text-gray-400" />
                            {officer.district}
                          </div>
                        </TableCell>
                        <TableCell>{officer.taluk}</TableCell>
                        <TableCell>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-blue-100 text-blue-800">
                            {assignedCount} assigned
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEdit(officer)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDelete(officer.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Officer Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingOfficer ? 'Edit Officer Details' : 'Add New Officer'}
            </DialogTitle>
            <DialogDescription>
              Fill in the officer details below
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter officer name"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="officer@revenue.gov.in"
                  required
                  disabled={!!editingOfficer}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">
                  Password {editingOfficer ? '(leave blank to keep current)' : '*'}
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="Enter password"
                  required={!editingOfficer}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+91 XXXXXXXXXX"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="district">District *</Label>
                <Select
                  value={formData.district}
                  onValueChange={(value) => setFormData({ ...formData, district: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select district" />
                  </SelectTrigger>
                  <SelectContent>
                    {districts.map((district) => (
                      <SelectItem key={district} value={district}>
                        {district}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="taluk">Taluk *</Label>
                <Select
                  value={formData.taluk}
                  onValueChange={(value) => setFormData({ ...formData, taluk: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select taluk" />
                  </SelectTrigger>
                  <SelectContent>
                    {taluks.map((taluk) => (
                      <SelectItem key={taluk} value={taluk}>
                        {taluk}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex gap-4 pt-4">
              <Button type="submit" className="flex-1">
                {editingOfficer ? 'Update Officer' : 'Add Officer'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setDialogOpen(false);
                  resetForm();
                }}
              >
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
