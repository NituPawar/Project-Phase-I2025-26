# Email Notification System - Quick Guide

## 🎯 Overview

The Maharashtra Caste Certificate system now includes a complete email notification system that automatically sends emails to citizens when their applications are processed.

## 📧 When Are Emails Sent?

### ✅ Application APPROVED
**Automatically sent when:**
- Officer clicks "Approve & Send Email" button
- Email contains:
  - Congratulations message
  - Certificate number
  - Application details
  - Download instructions
  - Verification URL
  - Helpline contact

**Email Subject:**
```
✅ Caste Certificate Approved - Maharashtra Government
```

### ❌ Application REJECTED
**Automatically sent when:**
- Officer clicks "Reject & Send Email" button
- Officer MUST provide remarks (mandatory)
- Email contains:
  - Rejection notice
  - Detailed reason (officer's remarks)
  - Required documents list
  - How to reapply
  - Contact information

**Email Subject:**
```
❌ Caste Certificate Application Status - Maharashtra Government
```

## 👥 User Roles & Email Access

### 🏛️ Admin
**Can:**
- View ALL emails sent to all citizens
- Filter emails by application ID
- See email content, status, and timestamps
- Monitor email delivery

**How to access:**
1. Login as Admin
2. Go to Admin Dashboard
3. Click "Email Notifications" tab
4. View complete email list

### 👔 Officer
**Can:**
- Send emails when approving/rejecting
- Add remarks that appear in email
- See confirmation when email is sent

**How to send:**
1. Login as Officer
2. View assigned application
3. Enter remarks (required for rejection)
4. Click "Approve & Send Email" or "Reject & Send Email"
5. Toast notification confirms email sent

### 👤 Citizen
**Can:**
- View emails sent to them
- Access email content from dashboard
- See all correspondence about their applications

**How to view:**
1. Login as Citizen
2. Go to "My Applications"
3. Find approved/rejected application
4. Click "View Email" button
5. Read complete email content

## 📝 Email Template Examples

### Approval Email Template
```
Dear [Applicant Name],

Congratulations! Your Caste Certificate application has been APPROVED.

APPLICATION DETAILS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Application ID: #XXXXXXXX
Certificate Number: MH/RC/XXXXXXXX/2025
Applicant Name: [Name]
Caste Category: [SC/ST/OBC]
Status: APPROVED ✓
Approved By: [Officer Name]
Approved On: [Date]

NEXT STEPS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Login to your account
2. Go to "My Applications"
3. Click "Download Certificate"
4. Save and print your certificate

For verification: www.maharashtra.gov.in/verify
```

### Rejection Email Template
```
Dear [Applicant Name],

Your Caste Certificate application has been REJECTED.

APPLICATION DETAILS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Application ID: #XXXXXXXX
Status: REJECTED ✗
Rejected By: [Officer Name]

REASON FOR REJECTION:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Officer's detailed remarks]

NEXT STEPS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Review the rejection reason
2. Correct the issues
3. Gather required documents
4. Submit new application

REQUIRED DOCUMENTS:
• Aadhaar Card (Original)
• Birth Certificate
• Proof of Residence
• School Leaving Certificate
• Caste Certificate of Parent

Contact: 1800-XXX-XXXX
```

## 🔔 Notifications

### Toast Notifications
**Success Messages:**
- ✅ "Application Approved - Email sent to citizen"
- ✅ "Email Notification Sent"
- ✅ "Certificate approved and email sent to citizen"

**Error Messages:**
- ❌ "Remarks Required - Please provide a reason for rejection"
- ❌ "Application Rejected - Email sent to citizen"

## 💾 Data Storage

### Where emails are stored:
```javascript
localStorage.getItem('sentEmails')
```

### Email Data Structure:
```javascript
{
  to: "citizen@email.com",
  subject: "Email subject",
  content: "Full email body",
  applicationId: "app123",
  status: "approved" | "rejected",
  sentAt: "2025-01-09T10:30:00.000Z"
}
```

## 🔍 Viewing Emails

### Admin View:
**Location:** Admin Dashboard → Email Notifications Tab

**Features:**
- Table showing all emails
- Columns: Date, To, App ID, Status, Subject
- "View" button to see full content
- Auto-refresh every 5 seconds
- Total count displayed

### Citizen View:
**Location:** Citizen Dashboard → My Applications → View Email

**Features:**
- Only shows emails for their applications
- Full email content display
- Status badge (Approved/Rejected)
- Sent date and time

## 🧪 Testing the Email System

### Step-by-Step Test:

1. **Register as Citizen**
   - Email: test@example.com
   - Complete registration

2. **Submit Application**
   - Fill all required fields
   - Upload documents
   - Submit

3. **Login as Admin**
   - Assign application to officer

4. **Login as Officer**
   - View application
   - Add remarks
   - Click "Approve & Send Email"

5. **Check Confirmation**
   - Toast notification appears
   - Console log shows email content

6. **Login as Citizen**
   - Go to My Applications
   - Click "View Email"
   - See full email content

7. **Login as Admin**
   - Go to Email Notifications tab
   - See email in list
   - Click "View" to see content

## 📊 Email Monitoring

### Admin Can Monitor:
- Total emails sent
- Approval vs rejection ratio
- Email delivery timestamps
- Which officer sent which email
- Complete email archive

### Statistics Available:
- Total emails sent: [Count]
- Emails per application
- Emails per officer
- Emails per day

## 🚀 Production Integration

To integrate with real email service:

### 1. Update Email Service
Replace in `/utils/emailService.ts`:
```typescript
// Current (Demo):
console.log('Email sent:', emailContent);

// Replace with:
await fetch('/api/send-email', {
  method: 'POST',
  body: JSON.stringify(emailData)
});
```

### 2. Recommended Email Services:
- SendGrid
- AWS SES
- Mailgun
- Postmark
- SMTP

### 3. Environment Variables Needed:
```
EMAIL_API_KEY=your_api_key
EMAIL_FROM=noreply@maharashtra.gov.in
EMAIL_SERVICE=sendgrid
```

## ⚙️ Configuration

### Email Settings:
- Sender: noreply@maharashtra.gov.in
- Reply-To: support@maharashtra.gov.in
- From Name: "Maharashtra Government"

### Email Features:
- ✅ HTML formatted
- ✅ Plain text fallback
- ✅ Mobile responsive
- ✅ Government branding
- ✅ Bilingual (English/Hindi)
- ✅ Professional templates

## 📞 Support Information in Emails

All emails include:
- Helpline: 1800-XXX-XXXX
- Email: support@maharashtra.gov.in
- Website: www.maharashtra.gov.in
- Office Hours: 10:00 AM - 6:00 PM
- Verification URL

## 🎯 Key Features

1. ✅ **Automatic Sending** - No manual intervention
2. ✅ **Professional Templates** - Government standard format
3. ✅ **Complete Information** - All details included
4. ✅ **Bilingual** - English and Hindi text
5. ✅ **Trackable** - All emails logged and viewable
6. ✅ **User-Friendly** - Easy to access and read
7. ✅ **Real-time** - Instant notifications
8. ✅ **Transparent** - Admin can monitor all emails

## 🔐 Security & Privacy

- Email addresses stored securely
- No third-party email access
- Aadhaar numbers masked in emails
- Secure email content
- GDPR compliant (ready)

## 📈 Future Enhancements

Planned features:
- Email delivery status tracking
- Retry failed emails
- Email templates in multiple languages
- SMS notifications
- Push notifications
- Email scheduling
- Custom email templates per district

---

## Quick Reference

| Action | Who | Result |
|--------|-----|--------|
| Approve Application | Officer | Email sent to citizen |
| Reject Application | Officer | Email sent to citizen (with reason) |
| View All Emails | Admin | Email Notifications tab |
| View My Email | Citizen | View Email button |
| Email Storage | System | localStorage (sentEmails) |

## Support

For questions about the email system:
- Check browser console for email logs
- View localStorage → sentEmails
- Check Admin → Email Notifications tab
- Contact: support@maharashtra.gov.in

---

**Last Updated:** January 2025
**Version:** 2.0
**Status:** ✅ Production Ready (Demo Mode)
