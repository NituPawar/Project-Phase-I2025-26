import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from './supabase/info';

interface EmailData {
  to: string;
  subject: string;
  applicantName: string;
  applicationId: string;
  status: 'approved' | 'rejected';
  remarks?: string;
  certificateNumber?: string;
  caste?: string;
  approvedBy?: string;
  approvedAt?: string;
}

export const sendEmailNotification = async (data: EmailData) => {
  const emailContent = generateEmailContent(data);
  const emailHtml = generateEmailHtml(data);
  
  // Log the email for debugging
  console.log('📧 EMAIL NOTIFICATION:');
  console.log('To:', data.to);
  console.log('Subject:', data.subject);
  console.log('Content:', emailContent);
  
  try {
    // Send email via backend API
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-27aaa517/send-email`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({
          to: data.to,
          subject: data.subject,
          html: emailHtml,
          text: emailContent,
        }),
      }
    );

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error || 'Failed to send email');
    }

    // Store email in localStorage for local viewing
    const emails = JSON.parse(localStorage.getItem('sentEmails') || '[]');
    emails.push({
      to: data.to,
      subject: data.subject,
      content: emailContent,
      sentAt: new Date().toISOString(),
      applicationId: data.applicationId,
      status: data.status
    });
    localStorage.setItem('sentEmails', JSON.stringify(emails));

    // Show success notification
    toast.success('Email Sent Successfully! ✅', {
      description: `Email delivered to ${data.to}`,
      duration: 5000,
    });

    return true;
  } catch (error) {
    console.error('Email sending error:', error);
    
    // Fallback: Store locally even if email fails
    const emails = JSON.parse(localStorage.getItem('sentEmails') || '[]');
    emails.push({
      to: data.to,
      subject: data.subject,
      content: emailContent,
      sentAt: new Date().toISOString(),
      applicationId: data.applicationId,
      status: data.status
    });
    localStorage.setItem('sentEmails', JSON.stringify(emails));
    
    toast.warning('Email Logged Locally', {
      description: 'Email service not configured. Check console for details.',
      duration: 5000,
    });
    
    return false;
  }
};

const generateEmailHtml = (data: EmailData): string => {
  const { status, applicantName, applicationId, remarks, certificateNumber, caste, approvedBy, approvedAt } = data;
  
  const baseStyle = `
    font-family: Arial, sans-serif;
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    background-color: #f9fafb;
  `;
  
  const headerStyle = `
    background: linear-gradient(to right, #f97316, #ffffff, #22c55e);
    padding: 3px;
    border-radius: 8px 8px 0 0;
  `;
  
  const contentStyle = `
    background-color: #ffffff;
    padding: 30px;
    border-radius: 0 0 8px 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  `;
  
  if (status === 'approved') {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="${baseStyle}">
        <div style="${headerStyle}"></div>
        <div style="${contentStyle}">
          <h1 style="color: #ea580c; margin-top: 0;">🎉 Congratulations!</h1>
          <h2 style="color: #1f2937;">Caste Certificate Approved</h2>
          <p style="color: #4b5563; font-size: 16px;">Dear ${applicantName},</p>
          <p style="color: #4b5563; font-size: 16px;">
            We are pleased to inform you that your Caste Certificate application has been <strong style="color: #22c55e;">APPROVED</strong>.
          </p>
          
          <div style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #92400e;">Application Details</h3>
            <p style="margin: 5px 0;"><strong>Application ID:</strong> #${applicationId.slice(0, 8)}</p>
            <p style="margin: 5px 0;"><strong>Certificate Number:</strong> ${certificateNumber}</p>
            <p style="margin: 5px 0;"><strong>Applicant Name:</strong> ${applicantName}</p>
            <p style="margin: 5px 0;"><strong>Caste Category:</strong> ${caste || 'N/A'}</p>
            <p style="margin: 5px 0;"><strong>Status:</strong> <span style="color: #22c55e; font-weight: bold;">✓ APPROVED</span></p>
            <p style="margin: 5px 0;"><strong>Approved By:</strong> ${approvedBy || 'Revenue Officer'}</p>
            <p style="margin: 5px 0;"><strong>Approved On:</strong> ${approvedAt ? new Date(approvedAt).toLocaleDateString('en-IN') : 'N/A'}</p>
            ${remarks ? `<p style="margin: 5px 0;"><strong>Remarks:</strong> ${remarks}</p>` : ''}
          </div>
          
          <div style="background-color: #dbeafe; padding: 15px; margin: 20px 0; border-radius: 8px;">
            <h3 style="margin-top: 0; color: #1e40af;">Next Steps</h3>
            <ol style="color: #1f2937; line-height: 1.8;">
              <li>Login to your account at <a href="https://maharashtra.gov.in" style="color: #2563eb;">maharashtra.gov.in</a></li>
              <li>Go to "My Applications" section</li>
              <li>Click on "Download Certificate" button</li>
              <li>Save and print your official certificate</li>
            </ol>
          </div>
          
          <div style="background-color: #f3f4f6; padding: 15px; margin: 20px 0; border-radius: 8px;">
            <h3 style="margin-top: 0; color: #374151;">Important Notes</h3>
            <ul style="color: #4b5563; line-height: 1.8;">
              <li>Your certificate is now available for download</li>
              <li>This is a digitally signed certificate and is valid for all purposes</li>
              <li>Keep your certificate safe for future reference</li>
              <li>For verification, visit: <a href="https://www.maharashtra.gov.in/verify" style="color: #2563eb;">www.maharashtra.gov.in/verify</a></li>
            </ul>
          </div>
          
          <div style="border-top: 2px solid #e5e7eb; padding-top: 15px; margin-top: 30px;">
            <p style="color: #6b7280; font-size: 14px;"><strong>Need Help?</strong></p>
            <p style="color: #6b7280; font-size: 14px; margin: 5px 0;">Helpline: 1800-XXX-XXXX</p>
            <p style="color: #6b7280; font-size: 14px; margin: 5px 0;">Email: support@maharashtra.gov.in</p>
          </div>
          
          <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
            <p style="color: #9ca3af; font-size: 12px; margin: 5px 0;">महाराष्ट्र शासन | Government of Maharashtra</p>
            <p style="color: #9ca3af; font-size: 12px; margin: 5px 0;">Revenue Department - Caste Certificate Services</p>
            <p style="color: #9ca3af; font-size: 12px; margin: 5px 0;">This is an automated email. Please do not reply to this message.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  } else {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="${baseStyle}">
        <div style="${headerStyle}"></div>
        <div style="${contentStyle}">
          <h1 style="color: #dc2626; margin-top: 0;">Application Status Update</h1>
          <h2 style="color: #1f2937;">Caste Certificate Application</h2>
          <p style="color: #4b5563; font-size: 16px;">Dear ${applicantName},</p>
          <p style="color: #4b5563; font-size: 16px;">
            We regret to inform you that your Caste Certificate application has been <strong style="color: #dc2626;">REJECTED</strong>.
          </p>
          
          <div style="background-color: #fee2e2; border-left: 4px solid #dc2626; padding: 15px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #991b1b;">Application Details</h3>
            <p style="margin: 5px 0;"><strong>Application ID:</strong> #${applicationId.slice(0, 8)}</p>
            <p style="margin: 5px 0;"><strong>Applicant Name:</strong> ${applicantName}</p>
            <p style="margin: 5px 0;"><strong>Caste Category:</strong> ${caste || 'N/A'}</p>
            <p style="margin: 5px 0;"><strong>Status:</strong> <span style="color: #dc2626; font-weight: bold;">✗ REJECTED</span></p>
            <p style="margin: 5px 0;"><strong>Rejected By:</strong> ${approvedBy || 'Revenue Officer'}</p>
          </div>
          
          <div style="background-color: #fef3c7; padding: 15px; margin: 20px 0; border-radius: 8px;">
            <h3 style="margin-top: 0; color: #92400e;">Reason for Rejection</h3>
            <p style="color: #78350f; font-size: 15px; line-height: 1.6;">${remarks || 'No specific reason provided'}</p>
          </div>
          
          <div style="background-color: #dbeafe; padding: 15px; margin: 20px 0; border-radius: 8px;">
            <h3 style="margin-top: 0; color: #1e40af;">Next Steps</h3>
            <ol style="color: #1f2937; line-height: 1.8;">
              <li>Review the rejection reason carefully</li>
              <li>Correct the issues mentioned above</li>
              <li>Gather all required documents</li>
              <li>Submit a new application with correct information</li>
            </ol>
          </div>
          
          <div style="background-color: #f3f4f6; padding: 15px; margin: 20px 0; border-radius: 8px;">
            <h3 style="margin-top: 0; color: #374151;">Required Documents</h3>
            <ul style="color: #4b5563; line-height: 1.8;">
              <li>Aadhaar Card (Original)</li>
              <li>Birth Certificate</li>
              <li>Proof of Residence</li>
              <li>School Leaving Certificate</li>
              <li>Caste Certificate of Parent (if applicable)</li>
              <li>Any other supporting documents</li>
            </ul>
          </div>
          
          <div style="border-top: 2px solid #e5e7eb; padding-top: 15px; margin-top: 30px;">
            <p style="color: #6b7280; font-size: 14px;"><strong>Need Help?</strong></p>
            <p style="color: #6b7280; font-size: 14px; margin: 5px 0;">Helpline: 1800-XXX-XXXX</p>
            <p style="color: #6b7280; font-size: 14px; margin: 5px 0;">Email: support@maharashtra.gov.in</p>
            <p style="color: #6b7280; font-size: 14px; margin: 5px 0;">Office Hours: 10:00 AM - 6:00 PM</p>
          </div>
          
          <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
            <p style="color: #9ca3af; font-size: 12px; margin: 5px 0;">महाराष्ट्र शासन | Government of Maharashtra</p>
            <p style="color: #9ca3af; font-size: 12px; margin: 5px 0;">Revenue Department - Caste Certificate Services</p>
            <p style="color: #9ca3af; font-size: 12px; margin: 5px 0;">This is an automated email. Please do not reply to this message.</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }
};

const generateEmailContent = (data: EmailData): string => {
  const { status, applicantName, applicationId, remarks, certificateNumber, caste, approvedBy, approvedAt } = data;
  
  if (status === 'approved') {
    return `
Dear ${applicantName},

Congratulations! We are pleased to inform you that your Caste Certificate application has been APPROVED.

APPLICATION DETAILS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Application ID: ${applicationId}
Certificate Number: MH/RC/${applicationId.slice(0, 8).toUpperCase()}/2025
Applicant Name: ${applicantName}
Caste Category: ${caste || 'N/A'}
Status: APPROVED ✓
Approved By: ${approvedBy || 'Revenue Officer'}
Approved On: ${approvedAt ? new Date(approvedAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' }) : 'N/A'}
${remarks ? `\nRemarks: ${remarks}` : ''}

NEXT STEPS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Login to your account at: https://maharashtra.gov.in
2. Go to "My Applications" section
3. Click on "Download Certificate" button
4. Save and print your official certificate

IMPORTANT NOTES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Your certificate is now available for download
• This is a digitally signed certificate and is valid for all purposes
• Keep your certificate safe for future reference
• For verification, visit: www.maharashtra.gov.in/verify

If you have any questions, please contact:
Helpline: 1800-XXX-XXXX
Email: support@maharashtra.gov.in

Thank you for using the Maharashtra Government Online Services.

Best Regards,
Revenue Department
Government of Maharashtra
महाराष्ट्र शासन

---
This is an automated email. Please do not reply to this message.
    `.trim();
  } else {
    return `
Dear ${applicantName},

We regret to inform you that your Caste Certificate application has been REJECTED.

APPLICATION DETAILS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Application ID: ${applicationId}
Applicant Name: ${applicantName}
Caste Category: ${caste || 'N/A'}
Status: REJECTED ✗
Rejected By: ${approvedBy || 'Revenue Officer'}

REASON FOR REJECTION:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${remarks || 'No specific reason provided'}

NEXT STEPS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Review the rejection reason carefully
2. Correct the issues mentioned above
3. Gather all required documents
4. Submit a new application with correct information

REQUIRED DOCUMENTS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Aadhaar Card (Original)
• Birth Certificate
• Proof of Residence
• School Leaving Certificate
• Caste Certificate of Parent (if applicable)
• Any other supporting documents

If you believe this rejection was made in error or need clarification, please contact:
Helpline: 1800-XXX-XXXX
Email: support@maharashtra.gov.in
Office Hours: 10:00 AM - 6:00 PM

Thank you for your understanding.

Best Regards,
Revenue Department
Government of Maharashtra
महाराष्ट्र शासन

---
This is an automated email. Please do not reply to this message.
    `.trim();
  }
};

export const getEmailPreview = (applicationId: string): any => {
  const emails = JSON.parse(localStorage.getItem('sentEmails') || '[]');
  return emails.filter((email: any) => email.applicationId === applicationId);
};

export const getAllEmails = (): any[] => {
  return JSON.parse(localStorage.getItem('sentEmails') || '[]');
};
