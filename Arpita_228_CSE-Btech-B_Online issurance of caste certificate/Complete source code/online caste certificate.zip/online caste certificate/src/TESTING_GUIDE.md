# 🧪 Testing Guide - Maharashtra Caste Certificate System

## ✅ All Errors Fixed!

All issues have been resolved. This guide will help you test every feature.

---

## 🏠 1. Test Homepage

### Steps:
1. **Open the application**
2. **You should see:**
   - ✅ Maharashtra Government branding
   - ✅ Slideshow with 4 images (auto-rotating every 5 seconds)
   - ✅ "सत्यमेव जयते" banner
   - ✅ Orange-White-Green tricolor theme
   - ✅ Features section with 4 cards
   - ✅ "How It Works" section
   - ✅ Call-to-action button
   - ✅ Footer with contact info

3. **Click "Login / Register" button**
   - Should navigate to login page

---

## 🔐 2. Test Login System

### Test Quick Login Buttons:

1. **Click "Login as Admin"**
   - Email: admin@revenue.gov.in
   - Should redirect to Admin Dashboard
   - Should see Maharashtra theme

2. **Click "Login as Officer"**
   - Email: officer1@revenue.gov.in
   - Should redirect to Officer Dashboard

3. **Click "Login as Citizen"**
   - Should redirect to Citizen Dashboard

### Test Manual Login:

1. **Enter credentials manually:**
   - Email: `admin@revenue.gov.in`
   - Password: `admin123`
   - Click "Login"

2. **Test wrong credentials:**
   - Enter: `wrong@email.com` / `wrongpass`
   - Should show: "Invalid email or password" error

---

## 👮 3. Test Admin Dashboard

### Login:
- Email: `admin@revenue.gov.in`
- Password: `admin123`

### Tab 1: Dashboard

**Statistics Cards:**
- ✅ Should show 4 cards: Total, Pending, Approved, Rejected
- ✅ Numbers should update in real-time (every 5 seconds)

**Real-Time Monitoring:**
- ✅ Table shows all applications
- ✅ Auto-refreshes every 5 seconds
- ✅ Shows Application ID, Name, Caste, Date, Status, Officer

**Assign Officer:**
1. Look for applications with "Pending" status
2. Click the dropdown under "Action"
3. Select an officer
4. Application status should change to "Under Review"
5. Should show assigned officer name

**User Statistics:**
- ✅ Left card: Shows all officers with their case count
- ✅ Right card: Shows registered citizens

### Tab 2: Manage Officers

**Add New Officer:**
1. Click "Add New Officer" button
2. Fill in all fields:
   - Name: Test Officer
   - Email: test@officer.com
   - Password: test123
   - Phone: +91 9999999999
   - District: Select from dropdown
   - Taluk: Select from dropdown
3. Click "Add Officer"
4. Should see success toast: "Officer added successfully"
5. Officer appears in table

**Edit Officer:**
1. Click edit icon (pencil) on any officer
2. Change any field (e.g., phone number)
3. Click "Update Officer"
4. Should see success toast: "Officer updated successfully"

**Delete Officer:**
1. Click delete icon (trash) on an officer
2. Confirm deletion
3. Should see success toast: "Officer deleted successfully"
4. Officer removed from table
5. Any assigned applications become "Pending" again

### Tab 3: Email Notifications

**View Emails:**
1. Click "Email Notifications" tab
2. Should see table with columns:
   - Date & Time
   - To (citizen email)
   - Application ID
   - Status (Approved/Rejected)
   - Subject
   - Action (View button)

**View Email Content:**
1. Click "View" button on any email
2. Should see dialog with:
   - Email recipient
   - Sent date/time
   - Application ID
   - Status badge
   - Full email content

**Auto-Refresh:**
- Table should refresh every 5 seconds
- New emails appear automatically

### Navigation:
- ✅ Click "Home" button → Returns to homepage
- ✅ Click "Logout" → Returns to homepage

---

## 👔 4. Test Officer Dashboard

### Login:
- Email: `officer1@revenue.gov.in`
- Password: `officer123`

### Statistics Cards:
- ✅ Assigned to Me: Total applications
- ✅ Under Review: Pending review
- ✅ Approved: Approved count
- ✅ Rejected: Rejected count

### View Application:

1. **Click "View" button on any application**
2. **Dialog should show:**
   - ✅ Application ID
   - ✅ Status badge
   - ✅ Applicant name
   - ✅ Father's name
   - ✅ Date of birth
   - ✅ Caste category
   - ✅ Phone number
   - ✅ Aadhaar number (masked: XXXX XXXX 1234)
   - ✅ Address
   - ✅ District
   - ✅ Documents list

### Approve Application:

1. **Open application with "Under Review" status**
2. **Enter remarks** (optional):
   - "All documents verified and found correct"
3. **Click "Approve & Send Email"**
4. **Should see:**
   - ✅ Success toast: "Application Approved - Certificate approved and email sent to citizen"
   - ✅ Another toast: "Email Notification Sent - Notification sent to [email]"
   - ✅ Dialog closes
   - ✅ Application status changes to "Approved"
   - ✅ "Certificate" button appears

5. **Check Console:**
   - Should see email content logged
   - Email includes certificate number, approval date, download instructions

### Reject Application:

1. **Open application with "Under Review" status**
2. **Enter remarks** (REQUIRED):
   - "Birth certificate date mismatch with application"
3. **Click "Reject & Send Email"**
4. **Should see:**
   - ✅ Success toast: "Application Rejected - Application rejected and email sent to citizen"
   - ✅ Toast: "Email Notification Sent"
   - ✅ Dialog closes
   - ✅ Application status changes to "Rejected"

5. **If you try to reject without remarks:**
   - ✅ Should see error toast: "Remarks Required - Please provide a reason for rejection"

### Download Certificate:

1. **Find approved application**
2. **Click "Certificate" button**
3. **New window opens with certificate:**
   - ✅ Maharashtra Government header
   - ✅ Tricolor borders (orange, white, green)
   - ✅ "महाराष्ट्र शासन" and "सत्यमेव जयते"
   - ✅ Certificate number: MH/RC/XXXXXXXX/2025
   - ✅ All applicant details
   - ✅ Aadhaar number (last 4 digits)
   - ✅ Officer signature
   - ✅ Official seal
   - ✅ "Print / Download PDF" button

### Navigation:
- ✅ Click "Home" → Returns to homepage
- ✅ Click "Logout" → Returns to homepage

---

## 👤 5. Test Citizen Dashboard

### Option 1: Register New Citizen

1. **From homepage, click "Login / Register"**
2. **Click "Register as Citizen"**
3. **Fill registration form:**
   - Full Name: John Doe
   - Email: john@example.com
   - Phone: +91 9876543210
   - Date of Birth: Select date
   - District: Select from dropdown
   - Address: Complete address
   - Password: citizen123
   - Confirm Password: citizen123
4. **Click "Register"**
5. **Should automatically login and go to dashboard**

### Option 2: Quick Login

1. **From login page, click "Login as Citizen"**

### Statistics Cards:
- ✅ Total Applications
- ✅ Pending/Under Review
- ✅ Approved
- ✅ Rejected

### Apply for New Certificate:

1. **Click "Apply for New Certificate" button**
2. **Fill application form:**
   - Applicant Name: (pre-filled)
   - Father's Name: Ram Doe
   - Date of Birth: Select date
   - Caste Category: SC / ST / OBC / NT
   - Phone: (pre-filled)
   - Aadhaar Number: 123456789012 (12 digits)
   - District: (pre-filled)
   - Address: (pre-filled)

3. **Upload Documents:**
   - Click "Choose Files"
   - Select multiple files (PDF, JPG, PNG)
   - Should see file names listed
   - ✅ File icons appear
   - ✅ File names displayed

4. **Click "Submit Application"**
5. **Should see:**
   - ✅ Dialog closes
   - ✅ New application appears in table
   - ✅ Status: "Pending"

### View Application Status:

**Table shows:**
- ✅ Application ID
- ✅ Applicant Name
- ✅ Caste
- ✅ Applied Date
- ✅ Status badge (color-coded)
- ✅ Actions column

### Download Approved Certificate:

1. **Wait for admin to assign and officer to approve**
2. **Status changes to "Approved"**
3. **"Download Certificate" button appears**
4. **Click button**
5. **Certificate opens in new window:**
   - ✅ All details from application
   - ✅ Aadhaar number included
   - ✅ Certificate number
   - ✅ Professional format
   - ✅ Print-ready

### View Rejection Reason:

1. **If application is rejected**
2. **Status shows "Rejected"**
3. **Below actions: "Reason: [Officer's remarks]"**

### Navigation:
- ✅ Click "Home" → Returns to homepage
- ✅ Click "Logout" → Returns to homepage

---

## 📧 6. Test Email System

### Setup:

1. **Open Browser Console** (F12 → Console tab)
2. **Keep it open while testing**

### Send Approval Email:

1. **Login as Citizen → Submit application**
2. **Login as Admin → Assign to officer**
3. **Login as Officer → Approve application**
4. **Check Console:**

```
📧 EMAIL NOTIFICATION:
To: citizen@email.com
Subject: ✅ Caste Certificate Approved - Maharashtra Government
Content: [Full email body]
```

### Send Rejection Email:

1. **Login as Officer**
2. **Reject application with remarks**
3. **Check Console:**

```
📧 EMAIL NOTIFICATION:
To: citizen@email.com
Subject: ❌ Caste Certificate Application Status - Maharashtra Government
Content: [Full email body with reason]
```

### View Email in Admin Dashboard:

1. **Login as Admin**
2. **Go to "Email Notifications" tab**
3. **Should see email in table**
4. **Click "View"**
5. **Full email content displays**

### Check localStorage:

1. **Open Browser DevTools (F12)**
2. **Go to Application → Local Storage**
3. **Check `sentEmails` key**
4. **Should see array of all sent emails**

---

## 🎯 7. Complete Workflow Test

### End-to-End Test:

1. ✅ **Citizen Registers**
   - Homepage → Login/Register → Register
   - Fill form → Submit
   - Auto-login to dashboard

2. ✅ **Citizen Applies**
   - Click "Apply for New Certificate"
   - Fill complete form with Aadhaar
   - Upload documents
   - Submit → Status: Pending

3. ✅ **Admin Assigns**
   - Login as Admin
   - Dashboard tab
   - Find pending application
   - Assign to Officer 1
   - Status → Under Review

4. ✅ **Officer Approves**
   - Login as Officer
   - View application details
   - Enter positive remarks
   - Click "Approve & Send Email"
   - Toast notifications appear
   - Email sent to citizen
   - Status → Approved

5. ✅ **Citizen Downloads**
   - Login as Citizen
   - See "Approved" status
   - Click "Download Certificate"
   - Certificate opens with all details
   - Print/Save certificate

6. ✅ **Admin Monitors**
   - Login as Admin
   - Go to Email Notifications tab
   - See approval email
   - View full content

---

## 🐛 8. Error Testing

### Test Invalid Inputs:

1. **Login with wrong password:**
   - ✅ Should show error message
   - ✅ No navigation

2. **Submit application without Aadhaar:**
   - ✅ Form validation prevents submit
   - ✅ Required field message

3. **Reject without remarks:**
   - ✅ Toast error appears
   - ✅ Rejection not processed

4. **Delete officer with applications:**
   - ✅ Confirmation dialog
   - ✅ Applications become pending
   - ✅ Officer deleted

### Test Edge Cases:

1. **No applications:**
   - ✅ Shows "No applications found" message

2. **No officers:**
   - ✅ Shows "No officers registered" message

3. **No emails sent:**
   - ✅ Shows "No emails sent yet" message

---

## 📊 9. Data Persistence Test

### Test localStorage:

1. **Login as Citizen**
2. **Submit application**
3. **Refresh browser (F5)**
4. **Check:**
   - ✅ Still logged in
   - ✅ Application still visible
   - ✅ Data persists

5. **Logout and login again:**
   - ✅ All data still there

### Check Stored Data:

**Open DevTools (F12) → Application → Local Storage:**

- ✅ `users` - All user accounts
- ✅ `applications` - All applications
- ✅ `sentEmails` - All sent emails
- ✅ `currentUser` - Current session

---

## 🎨 10. UI/UX Test

### Test Responsiveness:

1. **Resize browser window**
   - ✅ Layout adjusts smoothly
   - ✅ Mobile-friendly
   - ✅ Cards stack on small screens

### Test Animations:

1. **Homepage slideshow:**
   - ✅ Auto-rotates every 5 seconds
   - ✅ Smooth transitions
   - ✅ Manual controls work

2. **Toast notifications:**
   - ✅ Appear smoothly
   - ✅ Auto-dismiss after 5 seconds
   - ✅ Can be manually closed

### Test Maharashtra Theme:

1. **Check all pages have:**
   - ✅ Orange-White-Green colors
   - ✅ "महाराष्ट्र शासन" text
   - ✅ Tricolor elements
   - ✅ Government branding

---

## ✅ Success Checklist

After testing, verify all these work:

- [ ] Homepage loads with slideshow
- [ ] Login/Register works
- [ ] Admin can view dashboard
- [ ] Admin can manage officers (add/edit/delete)
- [ ] Admin can assign applications
- [ ] Admin can view all emails
- [ ] Officer can view assigned applications
- [ ] Officer can approve with email notification
- [ ] Officer can reject with email notification
- [ ] Citizen can register
- [ ] Citizen can apply with Aadhaar number
- [ ] Citizen can upload documents
- [ ] Citizen can download approved certificate
- [ ] Citizen can see rejection reason
- [ ] Emails are logged in console
- [ ] Emails stored in localStorage
- [ ] Toast notifications appear
- [ ] Certificate includes Aadhaar number
- [ ] Certificate has Maharashtra branding
- [ ] All data persists after refresh
- [ ] Navigation works (Home button)
- [ ] Logout works correctly
- [ ] Real-time updates work (5s refresh)
- [ ] Form validations work
- [ ] Error messages display correctly

---

## 🆘 Troubleshooting

### If something doesn't work:

1. **Clear Browser Cache:**
   - Press Ctrl+Shift+Delete
   - Clear all data
   - Refresh page

2. **Clear localStorage:**
   - Open DevTools (F12)
   - Application → Local Storage
   - Right-click → Clear
   - Refresh page

3. **Check Console for Errors:**
   - Open DevTools (F12)
   - Console tab
   - Look for red errors
   - Report the error message

4. **Verify Default Users Loaded:**
   - DevTools → Application → Local Storage
   - Check `users` key
   - Should have admin and officers

---

## 📝 Test Results Template

Use this to track your testing:

```
TEST DATE: __________
TESTER: __________

✅ Homepage: PASS / FAIL
✅ Login: PASS / FAIL
✅ Admin Dashboard: PASS / FAIL
✅ Officer Management: PASS / FAIL
✅ Email System: PASS / FAIL
✅ Officer Dashboard: PASS / FAIL
✅ Citizen Dashboard: PASS / FAIL
✅ Certificate Generation: PASS / FAIL
✅ Data Persistence: PASS / FAIL
✅ UI/UX: PASS / FAIL

NOTES:
_______________________
_______________________
```

---

**🎉 All features are working!**
**No errors remaining!**
**System is production-ready for demonstration!**
