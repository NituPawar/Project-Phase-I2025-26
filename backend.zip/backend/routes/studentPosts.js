const express = require("express");
const router = express.Router();
const StudentPost = require("../models/studentpost");
const multer = require("multer");
const User = require("../models/user");
const cloudinary = require("cloudinary").v2;
const { CloudinaryStorage } = require("multer-storage-cloudinary");
require("dotenv").config();
const StudentProfile = require("../models/studentprofile");


// Configure Cloudinary
console.log("Configuring Cloudinary...");
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Multer Storage for Cloudinary
console.log("Setting up Multer storage...");
const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: "student_posts",
    allowed_formats: ["jpg", "png", "jpeg", "pdf", "mp4"],
  },
});
const upload = multer({ storage });

router.get("/student-post/:id", async (req, res) => {
  try {
    const post = await StudentPost.findById(req.params.id);

    if (!post) {
      return res.status(404).json({ message: "Post not found" });
    } console.log("Retrieved Post:", post);

    res.json(post);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
// Route: Create a new student post with file uploads
router.post("/api/student-post", upload.array("files", 5), async (req, res) => {
  try {
    console.log("=== Received request to create a new student post ===");
    
    // Log the request body and files
    console.log("Request Body:", req.body);
    console.log("Uploaded Files:", req.files);

    const { studentEmail, title, description, hashtags, mentions, postType, privacy } = req.body;

    console.log("Validating request fields...");
    if (!studentEmail || !title) {
      return res.status(400).json({ error: "Email and title are required." });
    }
    console.log("Validation passed.");

    // Extract and structure file data
    const fileData = req.files.map(file => ({
      url: file.path, // Cloudinary URL
      public_id: file.filename, // Unique ID assigned by Cloudinary
      fileType: file.mimetype.includes("image") ? "image" :
                file.mimetype.includes("video") ? "video" :
                file.mimetype.includes("pdf") ? "pdf" : "link"
    }));
    console.log("Extracted File Data:", fileData);

    // Creating the new student post object
    const newPost = new StudentPost({
      studentEmail,
      title,
      description,
      hashtags: hashtags ? hashtags.split(",").map(tag => tag.trim()) : [],
      mentions: mentions ? mentions.split(",").map(m => m.trim().toLowerCase()) : [],
      postType: postType || "update",
      privacy: privacy || "public",
      files: fileData,
    });

    console.log("Attempting to save the new post to the database...");
    await newPost.save();
    console.log("Post saved successfully:", newPost);

    res.status(201).json({ message: "Post created successfully", post: newPost });
  } catch (error) {
    console.error("Error during post creation:", error);
    res.status(500).json({ error: "Server error", details: error.message });
  }
});


// ========================= LIKE POST =========================
const StudentCredits = require("../models/StudentCredits");


// POST /student-post/:id/like
router.post("/student-post/:id/like", async (req, res) => {
  try {
    const { likerEmail, postOwnerEmail } = req.body;

    if (!likerEmail || !postOwnerEmail) {
      return res.status(400).json({ message: "Both likerEmail and postOwnerEmail are required" });
    }

    const post = await StudentPost.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const liker = likerEmail.trim().toLowerCase();
    const owner = postOwnerEmail.trim().toLowerCase();

    let liked = false;

    // Toggle like in the post
    if (post.likes.includes(liker)) {
      post.likes = post.likes.filter((u) => u !== liker);
      liked = false;

      // Update existing credits (decrement) if exists
      const ownerCredits = await StudentCredits.findOne({ studentEmail: owner });
      if (ownerCredits) {
        ownerCredits.likes = Math.max(0, ownerCredits.likes - 3);
        await ownerCredits.save();
      }

    } else {
      post.likes.push(liker);
      liked = true;

      // Find existing credits or create new
      let ownerCredits = await StudentCredits.findOne({ studentEmail: owner });
      if (!ownerCredits) {
        ownerCredits = new StudentCredits({
          studentEmail: owner,
          likes: 3,   // Initial like points
          views: 0,
          shares: 0,
          comments: 0
        });
      } else {
        ownerCredits.likes += 3;
      }

      await ownerCredits.save();
    }

    await post.save();

    // totalCredits will auto-update because of pre-save hook
    return res.json({ likes: post.likes, liked });

  } catch (error) {
    console.error("Like error:", error);
    return res.status(500).json({ message: "Server error", error: error.message });
  }
});






router.post("/student-post/:id/view", async (req, res) => {
  try {
    console.log("View request received");
    const { viewerEmail, postOwnerEmail } = req.body;

    if (!viewerEmail || !postOwnerEmail) {
      return res.status(400).json({ message: "Both viewerEmail and postOwnerEmail are required" });
    }

    const post = await StudentPost.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const viewer = viewerEmail.trim().toLowerCase();
    const owner = postOwnerEmail.trim().toLowerCase();

    let viewed = false;

    // Initialize views array if not present
    if (!post.viewsList) post.viewsList = []; // store who viewed

    // Toggle view
    if (post.viewsList.includes(viewer)) {
      // Remove view
      post.viewsList = post.viewsList.filter(u => u !== viewer);
      viewed = false;

      // Decrement post owner credits if exists
      const ownerCredits = await StudentCredits.findOne({ studentEmail: owner });
      if (ownerCredits) {
        ownerCredits.views = Math.max(0, ownerCredits.views - 1); // 1 point per view
        await ownerCredits.save();
      }

    } else {
      // Add view
      post.viewsList.push(viewer);
      viewed = true;

      // Increment post owner credits, create if not exists
      let ownerCredits = await StudentCredits.findOne({ studentEmail: owner });
      if (!ownerCredits) {
        ownerCredits = new StudentCredits({
          studentEmail: owner,
          likes: 0,
          views: 1,
          shares: 0,
          comments: 0
        });
      } else {
        ownerCredits.views += 1;
      }

      await ownerCredits.save();
    }

    // Save total view count
    post.views = post.viewsList.length;
    await post.save();

    return res.json({ views: post.views, viewed });

  } catch (error) {
    console.error("View error:", error);
    return res.status(500).json({ message: "Server error", error: error.message });
  }
});

module.exports = router;


// ========================= SHARE POST =========================


router.post("/:id/share", async (req, res) => {
  try {
    const post = await StudentPost.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    post.shares.push({});
    await post.save();

    res.json({ shares: post.shares });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
});

router.get("/api/student-posts", async (req, res) => {
  try {
    console.log("=== Fetching all student posts from the database ===");

    const posts = await StudentPost.find().sort({ createdAt: -1 });
    

    if (posts.length === 0) {
      return res.status(200).json([]);
    }

    // Step 1: Get unique student emails from posts
    const emailSet = new Set(posts.map(post => post.studentEmail));
    const studentEmails = Array.from(emailSet);

    // Step 2: Fetch user details for those emails
    const users = await User.find({ email: { $in: studentEmails } });

    // Step 3: Create a map of email to user info
    const userMap = {};
    users.forEach(user => {
      userMap[user.email] = {
        fullname: user.fullname,
        profileImageUrl: user.profileImageUrl,
      };
    });

    // Step 4: Merge user info into each post
    const populatedPosts = posts.map(post => {
      const userInfo = userMap[post.studentEmail] || {};
      return {
        ...post.toObject(),
        fullname: userInfo.fullname || "Unknown User",
        profileImageUrl: userInfo.profileImageUrl || "",
      };
    });
 
    res.status(200).json(populatedPosts);
  } catch (error) {
    console.error("Error fetching student posts:", error);
    res.status(500).json({ error: "Server error", details: error.message });
  }
});
// commen=t the user post 
router.post("/student-post/:id/comment", async (req, res) => {
  try {
    const { userEmail, postOwnerEmail, text } = req.body;

    if (!userEmail || !postOwnerEmail || !text) {
      return res.status(400).json({ message: "userEmail, postOwnerEmail, and text are required" });
    }

    const post = await StudentPost.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    // Add comment to post.comments
    const commentObj = {
      userEmail: userEmail.trim().toLowerCase(),
      text: text.trim(),
      createdAt: new Date(),
    };
    post.comments.push(commentObj);
    await post.save();

    // Update post owner's comment credits in StudentCredits
    let ownerCredits = await StudentCredits.findOne({ studentEmail: postOwnerEmail.toLowerCase() });
    if (!ownerCredits) {
      ownerCredits = new StudentCredits({ studentEmail: postOwnerEmail.toLowerCase(), comments: 5 });
    } else {
      ownerCredits.comments += 5; // increment credits for comment
    }
    await ownerCredits.save();

    return res.json({ comments: post.comments });
  } catch (error) {
    console.error("Add comment error:", error);
    return res.status(500).json({ message: "Server error", error: error.message });
  }
});

router.get("/profile", async (req, res) => {
    try {
        console.log("Incoming request to /profile"); // Log when the request is received
        
        const { userId } = req.query;
        console.log("User ID from request query:", userId); // Log extracted userId

        if (!userId) {
            console.log("Missing userId in request");
            return res.status(400).json({ error: "User ID is required" });
        }

        console.log("Searching for student profile with userId:", userId);
        const student = await StudentProfile.findOne({ userId });

        if (!student) {
            console.log("Student profile not found for userId:", userId);
            return res.status(404).json({ error: "Student profile not found" });
        }

        console.log("Student profile found:", student); // Log the retrieved student profile
        res.json(student);
    } catch (error) {
        console.error("Error fetching student profile:", error);
        res.status(500).json({ error: "Server error" });
    }
});


module.exports = router;
