import { useState, useEffect } from 'react';
import { HomePage } from './components/HomePage';
import { LoginPage } from './components/LoginPage';
import { RegisterPage } from './components/RegisterPage';
import { AdminDashboard } from './components/AdminDashboard';
import { OfficerDashboard } from './components/OfficerDashboard';
import { CitizenDashboard } from './components/CitizenDashboard';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState<'home' | 'login' | 'register'>('home');

  useEffect(() => {
    // Initialize default users if not present
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    if (users.length === 0) {
      const defaultUsers = [
        { 
          id: '1', 
          email: 'admin@revenue.gov.in', 
          password: 'admin123', 
          role: 'admin', 
          name: 'Admin User',
          phone: '+91 9876543210',
          district: 'Mumbai City'
        },
        { 
          id: '2', 
          email: 'officer1@revenue.gov.in', 
          password: 'officer123', 
          role: 'officer', 
          name: 'Rajesh Kumar',
          phone: '+91 9876543211',
          district: 'Mumbai City',
          taluk: 'Taluk A'
        },
        { 
          id: '3', 
          email: 'officer2@revenue.gov.in', 
          password: 'officer123', 
          role: 'officer', 
          name: 'Priya Sharma',
          phone: '+91 9876543212',
          district: 'Pune',
          taluk: 'Taluk B'
        },
        { 
          id: '4', 
          email: 'officer3@revenue.gov.in', 
          password: 'officer123', 
          role: 'officer', 
          name: 'Amit Patil',
          phone: '+91 9876543213',
          district: 'Nagpur',
          taluk: 'Taluk C'
        }
      ];
      localStorage.setItem('users', JSON.stringify(defaultUsers));
    }

    // Check if user is logged in
    const user = localStorage.getItem('currentUser');
    if (user) {
      setCurrentUser(JSON.parse(user));
    }
  }, []);

  const handleLogin = (user: any) => {
    setCurrentUser(user);
    localStorage.setItem('currentUser', JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
    setCurrentPage('home');
  };

  const handleGoHome = () => {
    // Logout user and go to homepage
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
    setCurrentPage('home');
  };

  // If not logged in, show home/login/register pages
  if (!currentUser) {
    if (currentPage === 'home') {
      return <HomePage onLoginClick={() => setCurrentPage('login')} />;
    }

    return (
      <div className="min-h-screen">
        {currentPage === 'login' ? (
          <LoginPage 
            onLogin={handleLogin} 
            onSwitchToRegister={() => setCurrentPage('register')} 
          />
        ) : (
          <RegisterPage 
            onRegister={handleLogin} 
            onSwitchToLogin={() => setCurrentPage('login')} 
          />
        )}
      </div>
    );
  }

  // If logged in, show role-based dashboard
  return (
    <>
      <div className="min-h-screen bg-gray-50">
        {currentUser.role === 'admin' && (
          <AdminDashboard user={currentUser} onLogout={handleLogout} onGoHome={handleGoHome} />
        )}
        {currentUser.role === 'officer' && (
          <OfficerDashboard user={currentUser} onLogout={handleLogout} onGoHome={handleGoHome} />
        )}
        {currentUser.role === 'citizen' && (
          <CitizenDashboard user={currentUser} onLogout={handleLogout} onGoHome={handleGoHome} />
        )}
      </div>
      <Toaster />
    </>
  );
}
