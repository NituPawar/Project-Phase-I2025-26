const mongoose = require("mongoose");

const studentCreditsSchema = new mongoose.Schema({
  studentEmail: {       // Primary key: the student whose post is credited
    type: String,
    required: true,
    unique: true,
    lowercase: true,
  },
  likes: { type: Number, default: 0 },       // Credits for likes received
  views: { type: Number, default: 0 },       // Credits for views received
  shares: { type: Number, default: 0 },      // Credits for shares received
  comments: { type: Number, default: 0 },    // Credits for comments received
  totalCredits: { type: Number, default: 0 } // Total accumulated credits
}, { timestamps: true });

// Pre-save hook to auto-calculate totalCredits
studentCreditsSchema.pre("save", function (next) {
  this.totalCredits = this.likes + this.views + this.shares + this.comments;
  next();
});

module.exports = mongoose.model("StudentCredits", studentCreditsSchema);
