import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { LayoutDashboard, Users, FileText, LogOut, UserCheck, Clock, CheckCircle, XCircle, Activity, Home, Settings, Mail } from 'lucide-react';
import { OfficerManagement } from './OfficerManagement';
import { EmailNotifications } from './EmailNotifications';

interface AdminDashboardProps {
  user: any;
  onLogout: () => void;
  onGoHome: () => void;
}

export function AdminDashboard({ user, onLogout, onGoHome }: AdminDashboardProps) {
  const [applications, setApplications] = useState<any[]>([]);
  const [officers, setOfficers] = useState<any[]>([]);
  const [citizens, setCitizens] = useState<any[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    approved: 0,
    rejected: 0
  });

  useEffect(() => {
    loadData();
    // Set up real-time monitoring (refresh every 5 seconds)
    const interval = setInterval(loadData, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadData = () => {
    const apps = JSON.parse(localStorage.getItem('applications') || '[]');
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    setApplications(apps);
    setOfficers(users.filter((u: any) => u.role === 'officer'));
    setCitizens(users.filter((u: any) => u.role === 'citizen'));
    
    setStats({
      total: apps.length,
      pending: apps.filter((a: any) => a.status === 'pending').length,
      approved: apps.filter((a: any) => a.status === 'approved').length,
      rejected: apps.filter((a: any) => a.status === 'rejected').length
    });
  };

  const assignOfficer = (applicationId: string, officerId: string) => {
    const apps = JSON.parse(localStorage.getItem('applications') || '[]');
    const updatedApps = apps.map((app: any) => {
      if (app.id === applicationId) {
        return { ...app, assignedTo: officerId, status: 'under_review' };
      }
      return app;
    });
    localStorage.setItem('applications', JSON.stringify(updatedApps));
    loadData();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary"><Clock className="mr-1 h-3 w-3" />Pending</Badge>;
      case 'under_review':
        return <Badge className="bg-blue-500"><Activity className="mr-1 h-3 w-3" />Under Review</Badge>;
      case 'approved':
        return <Badge className="bg-green-500"><CheckCircle className="mr-1 h-3 w-3" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><XCircle className="mr-1 h-3 w-3" />Rejected</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header with Maharashtra Theme */}
      <div className="bg-gradient-to-r from-orange-500 via-white to-green-600 h-1"></div>
      <div className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center">
                <LayoutDashboard className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-orange-700">Admin Dashboard</h1>
                <p className="text-sm text-gray-600">महाराष्ट्र शासन - Revenue Department</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm">{user.name}</p>
                <p className="text-xs text-gray-500">Administrator</p>
              </div>
              <Button variant="outline" onClick={onGoHome}>
                <Home className="mr-2 h-4 w-4" />
                Home
              </Button>
              <Button variant="outline" onClick={onLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full max-w-2xl grid-cols-3">
            <TabsTrigger value="dashboard">
              <Activity className="mr-2 h-4 w-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="officers">
              <Settings className="mr-2 h-4 w-4" />
              Manage Officers
            </TabsTrigger>
            <TabsTrigger value="emails">
              <Mail className="mr-2 h-4 w-4" />
              Email Notifications
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            {/* Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="border-t-4 border-t-orange-500">
                <CardHeader className="pb-3">
                  <CardDescription>Total Applications</CardDescription>
                  <CardTitle className="text-orange-600">{stats.total}</CardTitle>
                </CardHeader>
                <CardContent>
                  <FileText className="h-8 w-8 text-orange-600 opacity-50" />
                </CardContent>
              </Card>
              <Card className="border-t-4 border-t-blue-500">
                <CardHeader className="pb-3">
                  <CardDescription>Pending</CardDescription>
                  <CardTitle className="text-blue-600">{stats.pending}</CardTitle>
                </CardHeader>
                <CardContent>
                  <Clock className="h-8 w-8 text-blue-600 opacity-50" />
                </CardContent>
              </Card>
              <Card className="border-t-4 border-t-green-500">
                <CardHeader className="pb-3">
                  <CardDescription>Approved</CardDescription>
                  <CardTitle className="text-green-600">{stats.approved}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CheckCircle className="h-8 w-8 text-green-600 opacity-50" />
                </CardContent>
              </Card>
              <Card className="border-t-4 border-t-red-500">
                <CardHeader className="pb-3">
                  <CardDescription>Rejected</CardDescription>
                  <CardTitle className="text-red-600">{stats.rejected}</CardTitle>
                </CardHeader>
                <CardContent>
                  <XCircle className="h-8 w-8 text-red-600 opacity-50" />
                </CardContent>
              </Card>
            </div>

            {/* Real-time Application Monitoring */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-green-500 animate-pulse" />
                  Real-Time Application Monitoring
                </CardTitle>
                <CardDescription>Live updates of all certificate applications (Auto-refresh every 5s)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Application ID</TableHead>
                        <TableHead>Applicant Name</TableHead>
                        <TableHead>Caste</TableHead>
                        <TableHead>Applied Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Assigned Officer</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {applications.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center text-gray-500">
                            No applications found
                          </TableCell>
                        </TableRow>
                      ) : (
                        applications.map((app) => (
                          <TableRow key={app.id}>
                            <TableCell className="font-mono text-xs">#{app.id.slice(0, 8)}</TableCell>
                            <TableCell>{app.applicantName}</TableCell>
                            <TableCell>{app.caste}</TableCell>
                            <TableCell>{new Date(app.createdAt).toLocaleDateString()}</TableCell>
                            <TableCell>{getStatusBadge(app.status)}</TableCell>
                            <TableCell>
                              {app.assignedTo ? (
                                <div className="flex items-center gap-2">
                                  <UserCheck className="h-4 w-4 text-green-600" />
                                  <span className="text-sm">{officers.find(o => o.id === app.assignedTo)?.name || 'Unknown'}</span>
                                </div>
                              ) : (
                                <span className="text-gray-400 text-sm">Not assigned</span>
                              )}
                            </TableCell>
                            <TableCell>
                              {!app.assignedTo && app.status === 'pending' && (
                                <Select onValueChange={(value) => assignOfficer(app.id, value)}>
                                  <SelectTrigger className="w-[180px]">
                                    <SelectValue placeholder="Assign Officer" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {officers.map((officer) => (
                                      <SelectItem key={officer.id} value={officer.id}>
                                        {officer.name}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            {/* User Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-orange-600" />
                    Registered Officers
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {officers.length === 0 ? (
                      <p className="text-gray-500 text-sm">No officers registered</p>
                    ) : (
                      officers.map((officer) => (
                        <div key={officer.id} className="flex items-center justify-between border-b pb-2">
                          <div>
                            <p>{officer.name}</p>
                            <p className="text-sm text-gray-500">{officer.email}</p>
                          </div>
                          <Badge variant="outline">
                            {applications.filter(a => a.assignedTo === officer.id).length} cases
                          </Badge>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-green-600" />
                    Registered Citizens
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {citizens.length === 0 ? (
                      <p className="text-gray-500 text-sm">No citizens registered</p>
                    ) : (
                      citizens.slice(0, 5).map((citizen) => (
                        <div key={citizen.id} className="flex items-center justify-between border-b pb-2">
                          <div>
                            <p>{citizen.name}</p>
                            <p className="text-sm text-gray-500">{citizen.email}</p>
                          </div>
                          <Badge variant="outline">
                            {applications.filter(a => a.citizenId === citizen.id).length} applications
                          </Badge>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="officers">
            <OfficerManagement />
          </TabsContent>

          <TabsContent value="emails">
            <EmailNotifications />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
