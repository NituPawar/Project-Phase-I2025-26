  const express = require("express");
  const router = express.Router();
  const AlumniPost = require("../models/alumnipost");
  const multer = require("multer");
  const cloudinary = require("cloudinary").v2;
  const { CloudinaryStorage } = require("multer-storage-cloudinary");
  require("dotenv").config();

const User = require("../models/user");


  // Configure Cloudinary
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  });

  // Multer Storage for Cloudinary
  const storage = new CloudinaryStorage({
    cloudinary: cloudinary,
    params: {
      folder: "alumni_posts",
      allowed_formats: ["jpg", "png", "jpeg"],
    },
  });
  const upload = multer({ storage });

  // Route: Create a new alumni post with image upload
  router.post("/api/alumniposts", upload.array("images", 5), async (req, res) => {
    try {
      console.log("Received request to create a new alumni post");

      // Log request body
      console.log("Request Body:", req.body);

      // Log uploaded files
      console.log("Uploaded Files:", req.files);

      const { alumni, title, description, company, location, jobType, stipend, applicationLink, skillsRequired, hashtags } = req.body;

      // Check for required fields
      if (!alumni || !title || !description || !company || !jobType || !applicationLink) {
        console.log("Error: Missing required fields");
        return res.status(400).json({ error: "Required fields are missing" });
      }

      // Extract Cloudinary URLs from uploaded images
      const imageUrls = req.files ? req.files.map(file => file.path) : [];

      console.log("Image URLs:", imageUrls);

      // Create a new post
      const newPost = new AlumniPost({
        alumni,
        title,
        description,
        company,
        location: location || "Remote",
        jobType,
        stipend: stipend || "Unpaid",
        applicationLink,
        skillsRequired: skillsRequired ? skillsRequired.split(",").map(skill => skill.trim()) : [],
        hashtags: hashtags ? hashtags.split(",").map(tag => tag.trim()) : [],
        images: imageUrls,
      });

      console.log("Saving new post to database:", newPost);

      await newPost.save();
      console.log("Post saved successfully");

      res.status(201).json({ message: "Post created successfully", post: newPost });
    } catch (error) {
      console.error("Error saving post:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  router.get("/api/alumniposts/alumni/:email", async (req, res) => {
  try {
    const { email } = req.params;

    const posts = await AlumniPost.find({ alumni: email });

    res.json(posts);
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Error fetching posts" });
  }
});

router.post("/api/alumniposts/:id/apply", async (req, res) => {
  try {
    const { id } = req.params;
    const { fullName, email } = req.body;

    if (!fullName || !email) {
      return res.status(400).json({ message: "Full Name & Email are required" });
    }

    const post = await AlumniPost.findById(id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    // prevent duplicate apply
    const exists = post.applied.some(a => a.email === email);
    if (exists) {
      return res.status(400).json({ message: "Already applied" });
    }

    post.applied.push({
      fullName,
      email,
      appliedAt: new Date(),
    });

    await post.save();

    res.json(post);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
});

  router.get("/api/alumniposts/:id", async (req, res) => {
  try {
    const post = await AlumniPost.findById(req.params.id);

    if (!post) return res.status(404).json({ message: "Post not found" });

    res.json(post);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
router.get("/api/alumniposts", async (req, res) => {
  try {
    // 1. Fetch all posts
    const posts = await AlumniPost.find();

    // 2. Get all unique alumni emails from the posts
    const alumniEmails = [...new Set(posts.map(post => post.alumni))];

    // 3. Fetch user details for these emails
    const users = await User.find({ email: { $in: alumniEmails } }, 'email fullname profileImageUrl');

    // 4. Create a lookup map from email -> user info
    const userMap = {};
    users.forEach(user => {
      userMap[user.email] = {
        fullname: user.fullname,
        profileImageUrl: user.profileImageUrl,
      };
    });

    // 5. Add user info to each post (attach to a new field or modify the existing)
    const enrichedPosts = posts.map(post => ({
      ...post.toObject(),
      creator: userMap[post.alumni] || null, // optional chaining
    }));

    res.status(200).json(enrichedPosts);
  } catch (error) {
    console.error("Error fetching posts:", error);
    res.status(500).json({ error: "Server error" });
  }
});

  
  
  module.exports = router;
