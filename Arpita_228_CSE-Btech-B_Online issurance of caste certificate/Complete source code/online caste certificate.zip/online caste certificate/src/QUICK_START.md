# 🚀 Quick Start Guide

## Get Started in 5 Minutes!

---

## 1️⃣ Open the Application

Just open the app in your browser. You'll see the **Maharashtra Government Homepage** with a beautiful slideshow.

---

## 2️⃣ Try Quick Login

Click **"Login / Register"** button on the homepage, then use these quick login buttons:

### 🔐 Pre-configured Accounts:

| Role | Email | Password | Quick Button |
|------|-------|----------|--------------|
| **Admin** | admin@revenue.gov.in | admin123 | "Login as Admin" |
| **Officer** | officer1@revenue.gov.in | officer123 | "Login as Officer" |
| **Citizen** | - | - | "Login as Citizen" |

---

## 3️⃣ Quick Test Scenarios

### 🎯 Scenario A: Admin Managing Officers (2 minutes)

1. Click **"Login as Admin"**
2. Click **"Manage Officers"** tab
3. Click **"Add New Officer"** button
4. Fill in the form:
   - Name: Test Officer
   - Email: test@officer.com
   - Password: test123
   - Phone: +91 9999999999
   - District: Mumbai City
   - Taluk: Taluk A
5. Click **"Add Officer"**
6. ✅ See success toast!
7. Officer appears in table

**What to check:**
- ✅ Green toast notification
- ✅ Officer in table with details
- ✅ Can edit/delete officer

---

### 🎯 Scenario B: Complete Application Flow (5 minutes)

#### Step 1: Citizen Applies
1. Logout (top-right button)
2. Homepage → **"Login / Register"**
3. Click **"Register as Citizen"**
4. Fill registration form
5. After registration, click **"Apply for New Certificate"**
6. Fill application:
   - Father's Name: Ram Kumar
   - Date of Birth: 01/01/1995
   - Caste: SC
   - Aadhaar: 123456789012
   - Upload some files
7. Click **"Submit Application"**
8. ✅ Application appears with "Pending" status

#### Step 2: Admin Assigns
1. Logout → Login as Admin
2. Dashboard tab → Find your application
3. In "Action" column, select an officer from dropdown
4. ✅ Status changes to "Under Review"

#### Step 3: Officer Approves
1. Logout → Login as Officer
2. See your assigned application
3. Click **"View"** button
4. Enter remarks: "All documents verified"
5. Click **"Approve & Send Email"**
6. ✅ See TWO toast notifications:
   - "Application Approved"
   - "Email Notification Sent"
7. Check browser console (F12) to see email content!

#### Step 4: Citizen Downloads
1. Logout → Login as Citizen
2. See "Approved" status with green badge
3. Click **"Download Certificate"** button
4. ✅ Beautiful Maharashtra certificate opens!
5. Certificate includes your Aadhaar number
6. Click **"Print / Download PDF"**

**What to check:**
- ✅ Complete workflow works
- ✅ Email notifications sent
- ✅ Certificate has all details
- ✅ Status updates in real-time

---

### 🎯 Scenario C: View Email Notifications (1 minute)

1. Login as Admin
2. Click **"Email Notifications"** tab
3. See all sent emails in table
4. Click **"View"** on any email
5. ✅ See complete email content

**What to check:**
- ✅ All emails listed
- ✅ Shows date, recipient, status
- ✅ Can view full email
- ✅ Auto-refreshes every 5s

---

## 4️⃣ Check the Console for Emails

Open browser console to see email logs:

1. Press **F12** (or right-click → Inspect)
2. Click **Console** tab
3. When officer approves/rejects, you'll see:

```
📧 EMAIL NOTIFICATION:
To: citizen@email.com
Subject: ✅ Caste Certificate Approved - Maharashtra Government
Content: [Full professional email]
```

---

## 5️⃣ Explore Features

### 🏠 Homepage Features:
- ✅ Auto-rotating slideshow (every 5s)
- ✅ Click arrows to manually change slides
- ✅ Click dots at bottom to jump to slide
- ✅ "सत्यमेव जयते" banner
- ✅ Features section
- ✅ How It Works guide

### 👮 Admin Dashboard:
- ✅ **Dashboard Tab**: Monitor all applications
- ✅ **Manage Officers Tab**: Add/Edit/Delete officers
- ✅ **Email Notifications Tab**: View all sent emails
- ✅ Real-time stats (refreshes every 5s)
- ✅ Assign applications to officers

### 👔 Officer Dashboard:
- ✅ View assigned applications
- ✅ Approve with automatic email
- ✅ Reject with automatic email
- ✅ Download certificates
- ✅ Toast notifications on actions

### 👤 Citizen Dashboard:
- ✅ Apply for certificates
- ✅ Upload documents
- ✅ Enter Aadhaar number
- ✅ Track application status
- ✅ Download approved certificates
- ✅ See rejection reasons

---

## 🎨 What to Notice

### Maharashtra Theme:
- 🟠 Orange, White, Green colors everywhere
- 🏛️ Government branding
- 📜 "महाराष्ट्र शासन" text
- 🇮🇳 Tricolor borders on certificate

### Toast Notifications:
- ✅ Green toast = Success
- ❌ Red toast = Error
- ℹ️ Blue toast = Info
- Auto-dismiss after 5 seconds

### Real-time Updates:
- Admin dashboard refreshes every 5 seconds
- Email tab refreshes automatically
- See changes without refresh

---

## 🔍 Where is the Data?

### Check localStorage:
1. Press **F12**
2. Go to **Application** tab
3. Click **Local Storage** on left
4. See stored data:
   - `users` - All accounts
   - `applications` - All applications
   - `sentEmails` - All sent emails
   - `currentUser` - Current session

---

## 🆘 Quick Troubleshooting

### Issue: "No applications showing"
**Solution:** Submit a test application first!

### Issue: "Can't assign officer"
**Solution:** Make sure application status is "Pending"

### Issue: "Email not appearing"
**Solution:** 
1. Open console (F12)
2. Email logs appear there
3. Check Admin → Email Notifications tab
4. Check localStorage → sentEmails

### Issue: "Data disappeared"
**Solution:** Data is in localStorage. If cleared, re-submit applications.

### Issue: "Quick login not working"
**Solution:** Refresh the page. Default users load on first visit.

---

## 📊 Test Checklist

Quick checklist to verify everything works:

- [ ] Homepage loads with slideshow
- [ ] Can login as Admin
- [ ] Can add new officer
- [ ] Can login as Citizen
- [ ] Can submit application
- [ ] Admin can assign application
- [ ] Officer can approve application
- [ ] Toast notifications appear
- [ ] Email logged in console
- [ ] Certificate downloads with Aadhaar
- [ ] Email appears in admin email tab

---

## 🎉 You're All Set!

### What You've Learned:
✅ How to login with different roles
✅ How to manage officers (Admin)
✅ How to submit applications (Citizen)
✅ How to approve/reject (Officer)
✅ How email notifications work
✅ How to view sent emails
✅ How to download certificates

### Next Steps:
1. **Read TESTING_GUIDE.md** for detailed testing
2. **Check EMAIL_SYSTEM_GUIDE.md** for email details
3. **Read PROJECT_INFO.md** for complete overview
4. **Explore all features yourself!**

---

## 💡 Pro Tips

1. **Keep Console Open**: Press F12 to see email logs
2. **Test Full Flow**: Citizen → Admin → Officer → Citizen
3. **Try Rejection**: Test both approve and reject flows
4. **Check Email Tab**: Admin can see all sent emails
5. **Use Quick Login**: Faster than typing credentials
6. **Watch Toast**: Notifications confirm every action
7. **Explore Tabs**: Admin has 3 tabs, try them all!

---

## 🏆 Challenge Tasks

Try these to master the system:

1. **Create 3 citizens** and submit 3 applications
2. **Add 2 new officers** with different districts
3. **Assign applications** to different officers
4. **Approve 2, reject 1** and check emails
5. **Download both certificates** and compare
6. **View all emails** in admin panel
7. **Delete an officer** and see applications become pending
8. **Register yourself** as a new citizen
9. **Submit your own application** with real data
10. **Complete the full cycle** end-to-end

---

**🚀 Ready to start? Just open the app!**

---

**Need Help?**
- Check **TESTING_GUIDE.md** for step-by-step instructions
- Check **EMAIL_SYSTEM_GUIDE.md** for email system details
- Check browser console for email logs
- Check localStorage for stored data

**Everything is working! Have fun exploring! 🎊**
