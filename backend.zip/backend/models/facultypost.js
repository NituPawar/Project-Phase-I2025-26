const mongoose = require("mongoose");

const FacultyPostSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
    },
    category: {
      type: String,
      enum: ["Workshop", "Training", "Placement", "Notice", "Other"],
    },
    files: [
      {
        url: { type: String },
        public_id: { type: String },
        fileType: String,
      },
    ],
    tags: {
      type: [String],
      default: [],
    },
    postedBy: {
      type: String, // previously: mongoose.Schema.Types.ObjectId
      required: true,
    },
    visibility: {
      type: String,
      enum: ["Public", "Students", "Faculty", "Alumni"],
      default: "Public",
    },
    status: {
      type: String,
      enum: ["Active", "Archived"],
      default: "Active",
    },
    likes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    views: {
      type: Number,
      default: 0,
    },
    comments: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        text: {
          type: String,
        },
        createdAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    pinned: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("FacultyPost", FacultyPostSchema);
