import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { UserCheck, LogOut, FileText, CheckCircle, XCircle, Eye, Download, Clock, Home, Mail, Image as ImageIcon } from 'lucide-react';
import { generateCertificate } from './CertificateGenerator';
import { sendEmailNotification } from '../utils/emailService';
import { toast } from 'sonner@2.0.3';

interface OfficerDashboardProps {
  user: any;
  onLogout: () => void;
  onGoHome: () => void;
}

export function OfficerDashboard({ user, onLogout, onGoHome }: OfficerDashboardProps) {
  const [applications, setApplications] = useState<any[]>([]);
  const [selectedApp, setSelectedApp] = useState<any>(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [remarks, setRemarks] = useState('');
  const [viewDocumentDialogOpen, setViewDocumentDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<any>(null);

  useEffect(() => {
    loadApplications();
  }, [user]);

  const loadApplications = () => {
    const apps = JSON.parse(localStorage.getItem('applications') || '[]');
    const myApps = apps.filter((app: any) => app.assignedTo === user.id);
    setApplications(myApps);
  };

  const handleApprove = async (appId: string) => {
    const apps = JSON.parse(localStorage.getItem('applications') || '[]');
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    let emailSent = false;
    
    const updatedApps = apps.map((app: any) => {
      if (app.id === appId) {
        const approvedApp = {
          ...app,
          status: 'approved',
          remarks: remarks || 'Application approved after verification',
          approvedBy: user.name,
          approvedAt: new Date().toISOString(),
          certificateNumber: `MH/RC/${app.id.slice(0, 8).toUpperCase()}/2025`
        };
        
        return approvedApp;
      }
      return app;
    });
    
    localStorage.setItem('applications', JSON.stringify(updatedApps));
    
    // Find the app and send email
    const app = apps.find((a: any) => a.id === appId);
    if (app) {
      const citizen = users.find((u: any) => u.id === app.citizenId);
      
      if (citizen && citizen.email) {
        // Send email notification asynchronously
        emailSent = await sendEmailNotification({
          to: citizen.email,
          subject: '✅ Caste Certificate Approved - Maharashtra Government',
          applicantName: app.applicantName,
          applicationId: app.id,
          status: 'approved',
          remarks: remarks || 'Application approved after verification',
          certificateNumber: `MH/RC/${app.id.slice(0, 8).toUpperCase()}/2025`,
          caste: app.caste,
          approvedBy: user.name,
          approvedAt: new Date().toISOString()
        });
      }
    }
    
    setRemarks('');
    setViewDialogOpen(false);
    loadApplications();
    
    toast.success('Application Approved', {
      description: emailSent ? 'Certificate approved and email sent to citizen' : 'Certificate approved (email delivery pending)',
    });
  };

  const handleReject = async (appId: string) => {
    if (!remarks) {
      toast.error('Remarks Required', {
        description: 'Please provide a reason for rejection',
      });
      return;
    }
    
    const apps = JSON.parse(localStorage.getItem('applications') || '[]');
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    let emailSent = false;
    
    const updatedApps = apps.map((app: any) => {
      if (app.id === appId) {
        const rejectedApp = {
          ...app,
          status: 'rejected',
          remarks: remarks,
          rejectedBy: user.name,
          rejectedAt: new Date().toISOString()
        };
        
        return rejectedApp;
      }
      return app;
    });
    
    localStorage.setItem('applications', JSON.stringify(updatedApps));
    
    // Find the app and send email
    const app = apps.find((a: any) => a.id === appId);
    if (app) {
      const citizen = users.find((u: any) => u.id === app.citizenId);
      
      if (citizen && citizen.email) {
        // Send email notification asynchronously
        emailSent = await sendEmailNotification({
          to: citizen.email,
          subject: '❌ Caste Certificate Application Status - Maharashtra Government',
          applicantName: app.applicantName,
          applicationId: app.id,
          status: 'rejected',
          remarks: remarks,
          caste: app.caste,
          approvedBy: user.name
        });
      }
    }
    
    setRemarks('');
    setViewDialogOpen(false);
    loadApplications();
    
    toast.error('Application Rejected', {
      description: emailSent ? 'Application rejected and email sent to citizen' : 'Application rejected (email delivery pending)',
    });
  };

  const downloadCertificate = (app: any) => {
    generateCertificate(app);
  };

  const handleViewDocument = (doc: any) => {
    setSelectedDocument(doc);
    setViewDocumentDialogOpen(true);
  };

  const handleDownloadDocument = (doc: any) => {
    if (!doc.data) {
      toast.error('Document Error', {
        description: 'Document data not available',
      });
      return;
    }

    try {
      // Extract base64 data (remove data:type;base64, prefix if present)
      const base64Data = doc.data.includes(',') ? doc.data.split(',')[1] : doc.data;
      const binaryString = atob(base64Data);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      
      const blob = new Blob([bytes], { type: doc.type || 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = doc.name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast.success('Document Downloaded', {
        description: `${doc.name} has been downloaded`,
      });
    } catch (error) {
      toast.error('Download Failed', {
        description: 'Failed to download document',
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary"><Clock className="mr-1 h-3 w-3" />Pending</Badge>;
      case 'under_review':
        return <Badge className="bg-blue-500">Under Review</Badge>;
      case 'approved':
        return <Badge className="bg-green-500"><CheckCircle className="mr-1 h-3 w-3" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><XCircle className="mr-1 h-3 w-3" />Rejected</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const stats = {
    total: applications.length,
    pending: applications.filter(a => a.status === 'under_review').length,
    approved: applications.filter(a => a.status === 'approved').length,
    rejected: applications.filter(a => a.status === 'rejected').length
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header with Maharashtra Theme */}
      <div className="bg-gradient-to-r from-orange-500 via-white to-green-600 h-1"></div>
      <div className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center">
                <UserCheck className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-orange-700">Officer Dashboard</h1>
                <p className="text-sm text-gray-600">महाराष्ट्र शासन - Revenue Department</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm">{user.name}</p>
                <p className="text-xs text-gray-500">Revenue Officer</p>
              </div>
              <Button variant="outline" onClick={onGoHome}>
                <Home className="mr-2 h-4 w-4" />
                Home
              </Button>
              <Button variant="outline" onClick={onLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-t-4 border-t-orange-500">
            <CardHeader className="pb-3">
              <CardDescription>Assigned to Me</CardDescription>
              <CardTitle className="text-orange-600">{stats.total}</CardTitle>
            </CardHeader>
            <CardContent>
              <FileText className="h-8 w-8 text-orange-600 opacity-50" />
            </CardContent>
          </Card>
          <Card className="border-t-4 border-t-blue-500">
            <CardHeader className="pb-3">
              <CardDescription>Under Review</CardDescription>
              <CardTitle className="text-blue-600">{stats.pending}</CardTitle>
            </CardHeader>
            <CardContent>
              <Clock className="h-8 w-8 text-blue-600 opacity-50" />
            </CardContent>
          </Card>
          <Card className="border-t-4 border-t-green-500">
            <CardHeader className="pb-3">
              <CardDescription>Approved</CardDescription>
              <CardTitle className="text-green-600">{stats.approved}</CardTitle>
            </CardHeader>
            <CardContent>
              <CheckCircle className="h-8 w-8 text-green-600 opacity-50" />
            </CardContent>
          </Card>
          <Card className="border-t-4 border-t-red-500">
            <CardHeader className="pb-3">
              <CardDescription>Rejected</CardDescription>
              <CardTitle className="text-red-600">{stats.rejected}</CardTitle>
            </CardHeader>
            <CardContent>
              <XCircle className="h-8 w-8 text-red-600 opacity-50" />
            </CardContent>
          </Card>
        </div>

        {/* Applications Table */}
        <Card>
          <CardHeader>
            <CardTitle>Assigned Applications</CardTitle>
            <CardDescription>Review and process certificate applications</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Application ID</TableHead>
                    <TableHead>Applicant</TableHead>
                    <TableHead>Caste</TableHead>
                    <TableHead>Applied Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {applications.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-gray-500">
                        No applications assigned to you
                      </TableCell>
                    </TableRow>
                  ) : (
                    applications.map((app) => (
                      <TableRow key={app.id}>
                        <TableCell className="font-mono text-xs">#{app.id.slice(0, 8)}</TableCell>
                        <TableCell>{app.applicantName}</TableCell>
                        <TableCell>{app.caste}</TableCell>
                        <TableCell>{new Date(app.createdAt).toLocaleDateString()}</TableCell>
                        <TableCell>{getStatusBadge(app.status)}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setSelectedApp(app);
                                setViewDialogOpen(true);
                              }}
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                            {app.status === 'approved' && (
                              <Button
                                size="sm"
                                className="bg-green-600 hover:bg-green-700"
                                onClick={() => downloadCertificate(app)}
                              >
                                <Download className="h-4 w-4 mr-1" />
                                Certificate
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* View Application Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Application Details</DialogTitle>
            <DialogDescription>
              Review application and take action
            </DialogDescription>
          </DialogHeader>
          {selectedApp && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Application ID</Label>
                  <p className="text-sm font-mono">#{selectedApp.id.slice(0, 8)}</p>
                </div>
                <div>
                  <Label>Status</Label>
                  <div className="mt-1">{getStatusBadge(selectedApp.status)}</div>
                </div>
                <div>
                  <Label>Applicant Name</Label>
                  <p className="text-sm">{selectedApp.applicantName}</p>
                </div>
                <div>
                  <Label>Father's Name</Label>
                  <p className="text-sm">{selectedApp.fatherName}</p>
                </div>
                <div>
                  <Label>Date of Birth</Label>
                  <p className="text-sm">{selectedApp.dob}</p>
                </div>
                <div>
                  <Label>Caste Category</Label>
                  <p className="text-sm">{selectedApp.caste}</p>
                </div>
                <div>
                  <Label>Phone</Label>
                  <p className="text-sm">{selectedApp.phone}</p>
                </div>
                <div>
                  <Label>Aadhaar Number</Label>
                  <p className="text-sm">{selectedApp.aadhaarNumber ? `XXXX XXXX ${selectedApp.aadhaarNumber.slice(-4)}` : 'N/A'}</p>
                </div>
                <div className="col-span-2">
                  <Label>Address</Label>
                  <p className="text-sm">{selectedApp.address}</p>
                </div>
                <div>
                  <Label>District</Label>
                  <p className="text-sm">{selectedApp.district}</p>
                </div>
              </div>

              <div>
                <Label>Documents Submitted</Label>
                <div className="mt-2 space-y-2">
                  {selectedApp.documents && selectedApp.documents.length > 0 ? (
                    selectedApp.documents.map((doc: any, idx: number) => (
                      <div key={idx} className="flex items-center justify-between gap-2 p-3 bg-orange-50 rounded-lg border border-orange-200">
                        <div className="flex items-center gap-2 flex-1">
                          {doc.type?.startsWith('image/') ? (
                            <ImageIcon className="h-5 w-5 text-orange-600" />
                          ) : (
                            <FileText className="h-5 w-5 text-orange-600" />
                          )}
                          <div className="flex-1">
                            <span className="text-sm font-medium">{doc.name}</span>
                            <p className="text-xs text-gray-500">
                              {doc.size ? `${(doc.size / 1024).toFixed(2)} KB` : 'Size unknown'} • {doc.type || 'Unknown type'}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          {doc.data ? (
                            <>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleViewDocument(doc)}
                                className="h-8"
                              >
                                <Eye className="h-4 w-4 mr-1" />
                                View
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDownloadDocument(doc)}
                                className="h-8"
                              >
                                <Download className="h-4 w-4 mr-1" />
                                Download
                              </Button>
                            </>
                          ) : (
                            <span className="text-xs text-gray-400 italic">Document data not available</span>
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-gray-500">No documents uploaded</p>
                  )}
                </div>
              </div>

              {selectedApp.status === 'under_review' && (
                <>
                  <div>
                    <Label htmlFor="remarks">Remarks / Comments</Label>
                    <Textarea
                      id="remarks"
                      placeholder="Enter your remarks here..."
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      className="mt-2"
                      rows={4}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      <Mail className="h-3 w-3 inline mr-1" />
                      An email will be sent to the citizen with your decision and remarks
                    </p>
                  </div>

                  <div className="flex gap-4">
                    <Button
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      onClick={() => handleApprove(selectedApp.id)}
                    >
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Approve & Send Email
                    </Button>
                    <Button
                      className="flex-1"
                      variant="destructive"
                      onClick={() => handleReject(selectedApp.id)}
                    >
                      <XCircle className="mr-2 h-4 w-4" />
                      Reject & Send Email
                    </Button>
                  </div>
                </>
              )}

              {selectedApp.remarks && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <Label>Officer Remarks</Label>
                  <p className="text-sm mt-1">{selectedApp.remarks}</p>
                  {selectedApp.approvedBy && (
                    <p className="text-xs text-gray-500 mt-2">
                      By: {selectedApp.approvedBy} on {new Date(selectedApp.approvedAt || selectedApp.rejectedAt).toLocaleDateString()}
                    </p>
                  )}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* View Document Dialog */}
      <Dialog open={viewDocumentDialogOpen} onOpenChange={setViewDocumentDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>View Document</DialogTitle>
            <DialogDescription>
              {selectedDocument?.name}
            </DialogDescription>
          </DialogHeader>
          {selectedDocument && selectedDocument.data && (
            <div className="space-y-4">
              {selectedDocument.type?.startsWith('image/') ? (
                <div className="flex justify-center bg-gray-100 rounded-lg p-4">
                  <img
                    src={selectedDocument.data}
                    alt={selectedDocument.name}
                    className="max-w-full max-h-[70vh] object-contain rounded"
                  />
                </div>
              ) : selectedDocument.type === 'application/pdf' ? (
                <div className="flex justify-center bg-gray-100 rounded-lg p-4">
                  <iframe
                    src={selectedDocument.data}
                    className="w-full h-[70vh] rounded border"
                    title={selectedDocument.name}
                  />
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center bg-gray-100 rounded-lg p-8 min-h-[200px]">
                  <FileText className="h-16 w-16 text-gray-400 mb-4" />
                  <p className="text-gray-600 mb-4">Preview not available for this file type</p>
                  <Button onClick={() => handleDownloadDocument(selectedDocument)}>
                    <Download className="h-4 w-4 mr-2" />
                    Download to View
                  </Button>
                </div>
              )}
              <div className="flex gap-2 pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => handleDownloadDocument(selectedDocument)}
                  className="flex-1"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download Document
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setViewDocumentDialogOpen(false)}
                >
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
