const mongoose = require("mongoose");

const alumniPostSchema = new mongoose.Schema(
  {
    alumni: {
      type: String, // Storing alumni email instead of ObjectId
      required: true,
      trim: true,
    },

    title: {
      type: String,
      required: true,
      trim: true,
    },

    description: {
      type: String,
      required: true,
    },

    company: {
      type: String,
      required: true,
      trim: true,
    },

    location: {
      type: String,
      default: "Remote",
      trim: true,
    },

    jobType: {
      type: String,
      enum: ["Internship", "Full-time job", "Part-time job", "Contract"],
      required: true,
    },

    stipend: {
      type: String,
      default: "Unpaid",
    },

    applicationLink: {
      type: [String],
      required: true,
      default: [],
    },

    skillsRequired: {
      type: [String],
      default: [],
    },

    hashtags: {
      type: [String],
      default: [],
    },

    images: {
      type: [String],
      default: [],
    },

    likes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],

    comments: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        text: {
          type: String,
          required: true,
        },
        createdAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],

    // ⭐ NEW FIELD ADDED
    applied: [
      {
        fullName: {
          type: String,
          required: true,
        },
        email: {
          type: String,
          required: true,
          trim: true,
        },
        appliedAt: {
          type: Date,
          default: Date.now,
        }
      }
    ],

  },
  { timestamps: true }
);

module.exports = mongoose.model("alumnipost", alumniPostSchema);
