const mongoose = require("mongoose");

const alumniProfileSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true,
        unique: true
    },
    fullName: {
        type: String
    },
    graduationYear: {
        type: Number
    },
    department: {
        type: String
    },
    degree: {
        type: String // e.g., B.Tech, M.Tech, MBA, Ph.D.
    },
    currentJobTitle: {
        type: String
    },
    company: {
        type: String
    },
    workLocation: {
        type: String
    },
    industry: {
        type: String // e.g., Software, Finance, Healthcare, Research
    },
    skills: {
        type: [String], // e.g., JavaScript, Python, Leadership
        default: []
    },
    linkedInProfile: {
        type: String
    },
    personalWebsite: {
        type: String
    },
    achievements: {
        type: [String], // List of awards, certifications, recognitions
        default: []
    },
    furtherEducation: {
        type: String // If the alumni pursued higher studies (e.g., MS at Stanford)
    },
    workExperience: {
        type: [
            {
                jobTitle: String,
                company: String,
                location: String,
                startDate: Date,
                endDate: Date
            }
        ],
        default: []
    },
    projects: {
        type: [
            {
                title: String,
                description: String,
                link: String
            }
        ],
        default: []
    },
    volunteerWork: {
        type: [
            {
                organization: String,
                role: String,
                description: String
            }
        ],
        default: []
    },
    contributionsToCollege: {
        type: [String] // e.g., Mentorship, Guest Lectures, Donations, Workshops
    },
    socialMedia: {
        facebook: { type: String },
        twitter: { type: String },
        github: { type: String }
    },
    contactNumber: {
        type: String
    },
    email: {
        type: String
    },
    address: {
        type: String
    },
    hobbies: {
        type: [String], // List of hobbies or interests
        default: []
    },
    dateCreated: {
        type: Date,
        default: Date.now
    }
});

const AlumniProfile = mongoose.model("AlumniProfile", alumniProfileSchema);
module.exports = AlumniProfile;
