const mongoose = require("mongoose");

const facultyProfileSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true,
        unique: true
    },
    fullName: {
        type: String
    },
    department: {
        type: String
    },
    designation: {
        type: String // e.g., Assistant Professor, Associate Professor, Professor
    },
    specialization: {
        type: [String], // Multiple specializations allowed
        default: []
    },
    experience: {
        type: Number // Experience in years
    },
    qualifications: {
        type: [String], // e.g., Ph.D., M.Tech, PostDoc
        default: []
    },
    contactNumber: {
        type: String
    },
    email: {
        type: String
    },
    officeLocation: {
        type: String
    },
    researchPublications: {
        type: [
            {
                title: String,
                journal: String,
                year: Number,
                link: String
            }
        ],
        default: []
    },
    booksAuthored: {
        type: [
            {
                title: String,
                publisher: String,
                year: Number
            }
        ],
        default: []
    },
    patents: {
        type: [
            {
                title: String,
                patentNumber: String,
                year: Number
            }
        ],
        default: []
    },
    projectsSupervised: {
        type: [
            {
                title: String,
                level: String, // UG, PG, Ph.D.
                year: Number
            }
        ],
        default: []
    },
    professionalMemberships: {
        type: [String], // IEEE, ACM, etc.
        default: []
    },
    awards: {
        type: [String], // Teaching, Research, Excellence Awards
        default: []
    },
    workshopsConducted: {
        type: [
            {
                title: String,
                date: Date,
                location: String
            }
        ],
        default: []
    },
    guestLectures: {
        type: [
            {
                topic: String,
                institution: String,
                date: Date
            }
        ],
        default: []
    },
    socialMedia: {
        linkedIn: { type: String },
        googleScholar: { type: String },
        researchGate: { type: String }
    },
    dateJoined: {
        type: Date
    },
    dateCreated: {
        type: Date,
        default: Date.now
    }
});

const FacultyProfile = mongoose.model("FacultyProfile", facultyProfileSchema);
module.exports = FacultyProfile;
