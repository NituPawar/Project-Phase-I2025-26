const mongoose = require("mongoose");

const connectionSchema = new mongoose.Schema(
  {
    userEmail: {          // The user whose connections we are storing
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    connections: [        // List of connected users’ emails
      {
        type: String,
        lowercase: true,
        trim: true,
      }
    ]
  },
  { timestamps: true }
);

module.exports = mongoose.model("Connections", connectionSchema);
